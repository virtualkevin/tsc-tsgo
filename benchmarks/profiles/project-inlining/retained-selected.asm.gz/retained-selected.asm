TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbol(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:16409	0x800260		493b6610		CMPQ SP, 0x10(R14)												
  checker.go:16409	0x800264		0f86ce000000		JBE 0x800338													
  checker.go:16409	0x80026a		55			PUSHQ BP													
  checker.go:16409	0x80026b		4889e5			MOVQ SP, BP													
  checker.go:16409	0x80026e		4883ec10		SUBQ $0x10, SP													
  checker.go:16410	0x800272		8b4b04			MOVL 0x4(BX), CX												
  checker.go:16410	0x800275		0fbae110		BTL $0x10, CX													
  checker.go:16410	0x800279		0f82ae000000		JB 0x80032d													
  checker.go:16413	0x80027f		0fbae100		BTL $0x0, CX													
  checker.go:16413	0x800283		0f8299000000		JB 0x800322													
  checker.go:16416	0x800289		0fbae112		BTL $0x12, CX													
  checker.go:16416	0x80028d		0f8284000000		JB 0x800317													
  checker.go:16419	0x800293		0fbae10d		BTL $0xd, CX													
  checker.go:16419	0x800297		7273			JB 0x80030c													
  checker.go:16422	0x800299		8b0b			MOVL 0(BX), CX													
  checker.go:16422	0x80029b		0f1f440000		NOPL 0(AX)(AX*1)												
  checker.go:16422	0x8002a0		f7c100800100		TESTL $0x18000, CX												
  checker.go:16422	0x8002a6		7559			JNE 0x800301													
  checker.go:16425	0x8002a8		f7c107000000		TESTL $0x7, CX													
  checker.go:16425	0x8002ae		7546			JNE 0x8002f6													
  checker.go:16428	0x8002b0		f7c1b0230000		TESTL $0x23b0, CX												
  checker.go:16428	0x8002b6		7533			JNE 0x8002eb													
  checker.go:16431	0x8002b8		0fbae103		BTL $0x3, CX													
  checker.go:16431	0x8002bc		7222			JB 0x8002e0													
  checker.go:16434	0x8002be		0fbae115		BTL $0x15, CX													
  checker.go:16434	0x8002c2		730b			JAE 0x8002cf													
  checker.go:16435	0x8002c4		e8d7cd0000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfAlias(SB)				
  checker.go:16435	0x8002c9		4883c410		ADDQ $0x10, SP													
  checker.go:16435	0x8002cd		5d			POPQ BP														
  checker.go:16435	0x8002ce		c3			RET														
  checker.go:16437	0x8002cf		488b80900b0000		MOVQ 0xb90(AX), AX												
  checker.go:16437	0x8002d6		4883c410		ADDQ $0x10, SP													
  checker.go:16437	0x8002da		5d			POPQ BP														
  checker.go:16437	0x8002db		c3			RET														
  checker.go:16437	0x8002dc		0f1f4000		NOPL 0(AX)													
  checker.go:16432	0x8002e0		e83bc20000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfEnumMember(SB)			
  checker.go:16432	0x8002e5		4883c410		ADDQ $0x10, SP													
  checker.go:16432	0x8002e9		5d			POPQ BP														
  checker.go:16432	0x8002ea		c3			RET														
  checker.go:16429	0x8002eb		e850220000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfFuncClassEnumModule(SB)		
  checker.go:16429	0x8002f0		4883c410		ADDQ $0x10, SP													
  checker.go:16429	0x8002f4		5d			POPQ BP														
  checker.go:16429	0x8002f5		c3			RET														
  checker.go:16426	0x8002f6		e845020000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfVariableOrParameterOrProperty(SB)	
  checker.go:16426	0x8002fb		4883c410		ADDQ $0x10, SP													
  checker.go:16426	0x8002ff		5d			POPQ BP														
  checker.go:16426	0x800300		c3			RET														
  checker.go:16423	0x800301		e8bac20000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfAccessors(SB)			
  checker.go:16423	0x800306		4883c410		ADDQ $0x10, SP													
  checker.go:16423	0x80030a		5d			POPQ BP														
  checker.go:16423	0x80030b		c3			RET														
  checker.go:16420	0x80030c		e80f0c0900		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfReverseMappedSymbol(SB)		
  checker.go:16420	0x800311		4883c410		ADDQ $0x10, SP													
  checker.go:16420	0x800315		5d			POPQ BP														
  checker.go:16420	0x800316		c3			RET														
  checker.go:16417	0x800317		e804c10100		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfMappedSymbol(SB)			
  checker.go:16417	0x80031c		4883c410		ADDQ $0x10, SP													
  checker.go:16417	0x800320		5d			POPQ BP														
  checker.go:16417	0x800321		c3			RET														
  checker.go:16414	0x800322		e899000000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfInstantiatedSymbol(SB)		
  checker.go:16414	0x800327		4883c410		ADDQ $0x10, SP													
  checker.go:16414	0x80032b		5d			POPQ BP														
  checker.go:16414	0x80032c		c3			RET														
  checker.go:16411	0x80032d		e88ef7ffff		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbolWithDeferredType(SB)		
  checker.go:16411	0x800332		4883c410		ADDQ $0x10, SP													
  checker.go:16411	0x800336		5d			POPQ BP														
  checker.go:16411	0x800337		c3			RET														
  checker.go:16409	0x800338		4889442408		MOVQ AX, 0x8(SP)												
  checker.go:16409	0x80033d		48895c2410		MOVQ BX, 0x10(SP)												
  checker.go:16409	0x800342		e8b9f6c8ff		CALL runtime.morestack_noctxt.abi0(SB)										
  checker.go:16409	0x800347		488b442408		MOVQ 0x8(SP), AX												
  checker.go:16409	0x80034c		488b5c2410		MOVQ 0x10(SP), BX												
  checker.go:16409	0x800351		e90affffff		JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbol(SB)				

TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfInstantiatedSymbol(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:16444	0x8003c0		493b6610		CMPQ SP, 0x10(R14)																											
  checker.go:16444	0x8003c4		0f8688000000		JBE 0x800452																												
  checker.go:16444	0x8003ca		55			PUSHQ BP																												
  checker.go:16444	0x8003cb		4889e5			MOVQ SP, BP																												
  checker.go:16444	0x8003ce		4883ec28		SUBQ $0x28, SP																												
  checker.go:16446	0x8003d2		4889442438		MOVQ AX, 0x38(SP)																											
  checker.go:16445	0x8003d7		8400			TESTB AL, 0(AX)																												
  checker.go:16445	0x8003d9		480540090000		ADDQ $0x940, AX																												
  checker.go:16445	0x8003df		4889d9			MOVQ BX, CX																												
  checker.go:16445	0x8003e2		488d1d17acd400		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), BX			
  checker.go:16445	0x8003e9		e812541000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).Get(SB)	
  checker.go:16446	0x8003ee		48833800		CMPQ 0(AX), $0x0																											
  checker.go:16446	0x8003f2		7555			JNE 0x800449																												
  checker.go:16445	0x8003f4		4889442420		MOVQ AX, 0x20(SP)																											
  checker.go:16447	0x8003f9		488b5810		MOVQ 0x10(AX), BX																											
  checker.go:16447	0x8003fd		488b442438		MOVQ 0x38(SP), AX																											
  checker.go:16447	0x800402		e859feffff		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbol(SB)																			
  checker.go:16447	0x800407		488b4c2420		MOVQ 0x20(SP), CX																											
  checker.go:16447	0x80040c		488b4918		MOVQ 0x18(CX), CX																											
  checker.go:21998	0x800410		4889c3			MOVQ AX, BX																												
  checker.go:21998	0x800413		31ff			XORL DI, DI																												
  checker.go:21998	0x800415		488b442438		MOVQ 0x38(SP), AX																											
  checker.go:21998	0x80041a		e861430200		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateTypeWithAlias(SB)																	
  checker.go:16447	0x80041f		833dea806f0100		CMPL runtime.writeBarrier(SB), $0x0																									
  checker.go:16447	0x800426		7507			JNE 0x80042f																												
  checker.go:16447	0x800428		488b4c2420		MOVQ 0x20(SP), CX																											
  checker.go:16447	0x80042d		eb14			JMP 0x800443																												
  checker.go:16447	0x80042f		488b4c2420		MOVQ 0x20(SP), CX																											
  checker.go:16447	0x800434		488b11			MOVQ 0(CX), DX																												
  checker.go:16447	0x800437		e8c410c9ff		CALL runtime.gcWriteBarrier2(SB)																									
  checker.go:16447	0x80043c		498903			MOVQ AX, 0(R11)																												
  checker.go:16447	0x80043f		49895308		MOVQ DX, 0x8(R11)																											
  checker.go:16447	0x800443		488901			MOVQ AX, 0(CX)																												
  checker.go:16449	0x800446		4889c8			MOVQ CX, AX																												
  checker.go:16449	0x800449		488b00			MOVQ 0(AX), AX																												
  checker.go:16449	0x80044c		4883c428		ADDQ $0x28, SP																												
  checker.go:16449	0x800450		5d			POPQ BP																													
  checker.go:16449	0x800451		c3			RET																													
  checker.go:16444	0x800452		4889442408		MOVQ AX, 0x8(SP)																											
  checker.go:16444	0x800457		48895c2410		MOVQ BX, 0x10(SP)																											
  checker.go:16444	0x80045c		0f1f4000		NOPL 0(AX)																												
  checker.go:16444	0x800460		e89bf5c8ff		CALL runtime.morestack_noctxt.abi0(SB)																									
  checker.go:16444	0x800465		488b442408		MOVQ 0x8(SP), AX																											
  checker.go:16444	0x80046a		488b5c2410		MOVQ 0x10(SP), BX																											
  checker.go:16444	0x80046f		e94cffffff		JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfInstantiatedSymbol(SB)																	

TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateType(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:21997	0x824720		493b6610		CMPQ SP, 0x10(R14)											
  checker.go:21997	0x824724		7615			JBE 0x82473b												
  checker.go:21997	0x824726		55			PUSHQ BP												
  checker.go:21997	0x824727		4889e5			MOVQ SP, BP												
  checker.go:21997	0x82472a		4883ec20		SUBQ $0x20, SP												
  checker.go:21998	0x82472e		31ff			XORL DI, DI												
  checker.go:21998	0x824730		e84b000000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateTypeWithAlias(SB)	
  checker.go:21998	0x824735		4883c420		ADDQ $0x20, SP												
  checker.go:21998	0x824739		5d			POPQ BP													
  checker.go:21998	0x82473a		c3			RET													
  checker.go:21997	0x82473b		4889442408		MOVQ AX, 0x8(SP)											
  checker.go:21997	0x824740		48895c2410		MOVQ BX, 0x10(SP)											
  checker.go:21997	0x824745		48894c2418		MOVQ CX, 0x18(SP)											
  checker.go:21997	0x82474a		e8b1b2c6ff		CALL runtime.morestack_noctxt.abi0(SB)									
  checker.go:21997	0x82474f		488b442408		MOVQ 0x8(SP), AX											
  checker.go:21997	0x824754		488b5c2410		MOVQ 0x10(SP), BX											
  checker.go:21997	0x824759		488b4c2418		MOVQ 0x18(SP), CX											
  checker.go:21997	0x82475e		6690			NOPW													
  checker.go:21997	0x824760		ebbe			JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateType(SB)			

TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).newType(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:24944	0x838380		493b6610		CMPQ SP, 0x10(R14)																		
  checker.go:24944	0x838384		0f8617010000		JBE 0x8384a1																			
  checker.go:24944	0x83838a		55			PUSHQ BP																			
  checker.go:24944	0x83838b		4889e5			MOVQ SP, BP																			
  checker.go:24944	0x83838e		4883ec28		SUBQ $0x28, SP																			
  checker.go:24952	0x838392		4889442438		MOVQ AX, 0x38(SP)																		
  checker.go:24952	0x838397		895c2440		MOVL BX, 0x40(SP)																		
  checker.go:24952	0x83839b		894c2444		MOVL CX, 0x44(SP)																		
  checker.go:24952	0x83839f		4889742450		MOVQ SI, 0x50(SP)																		
  checker.go:24952	0x8383a4		48897c2448		MOVQ DI, 0x48(SP)																		
  checker.go:24945	0x8383a9		ff4058			INCL 0x58(AX)																			
  checker.go:24946	0x8383ac		488b4f38		MOVQ 0x38(DI), CX																		
  checker.go:24946	0x8383b0		4889f0			MOVQ SI, AX																			
  checker.go:24946	0x8383b3		ffd1			CALL CX																				
  checker.go:24947	0x8383b5		8b4c2440		MOVL 0x40(SP), CX																		
  checker.go:24947	0x8383b9		8908			MOVL CX, 0(AX)																			
  checker.go:24948	0x8383bb		8b4c2444		MOVL 0x44(SP), CX																		
  checker.go:24948	0x8383bf		81e1ffffc7ff		ANDL $-0x380001, CX																		
  checker.go:24948	0x8383c5		894804			MOVL CX, 0x4(AX)																		
  checker.go:24949	0x8383c8		488b4c2438		MOVQ 0x38(SP), CX																		
  checker.go:24949	0x8383cd		8b5158			MOVL 0x58(CX), DX																		
  checker.go:24949	0x8383d0		895008			MOVL DX, 0x8(AX)																		
  checker.go:24950	0x8383d3		833d36016c0100		CMPL runtime.writeBarrier(SB), $0x0																
  checker.go:24950	0x8383da		7507			JNE 0x8383e3																			
  checker.go:24951	0x8383dc		488b542450		MOVQ 0x50(SP), DX																		
  checker.go:24950	0x8383e1		eb21			JMP 0x838404																			
  checker.go:24950	0x8383e3		488b5020		MOVQ 0x20(AX), DX																		
  checker.go:24951	0x8383e7		488b5830		MOVQ 0x30(AX), BX																		
  checker.go:24950	0x8383eb		e85091c5ff		CALL runtime.gcWriteBarrier4(SB)																
  checker.go:24950	0x8383f0		49890b			MOVQ CX, 0(R11)																			
  checker.go:24950	0x8383f3		49895308		MOVQ DX, 0x8(R11)																		
  checker.go:24951	0x8383f7		488b542450		MOVQ 0x50(SP), DX																		
  checker.go:24951	0x8383fc		49895310		MOVQ DX, 0x10(R11)																		
  checker.go:24951	0x838400		49895b18		MOVQ BX, 0x18(R11)																		
  checker.go:24950	0x838404		48894820		MOVQ CX, 0x20(AX)																		
  checker.go:24951	0x838408		488b5c2448		MOVQ 0x48(SP), BX																		
  checker.go:24951	0x83840d		48895828		MOVQ BX, 0x28(AX)																		
  checker.go:24951	0x838411		48895030		MOVQ DX, 0x30(AX)																		
  checker.go:24952	0x838415		488b89d0120000		MOVQ 0x12d0(CX), CX																		
  checker.go:24952	0x83841c		0f1f4000		NOPL 0(AX)																			
  checker.go:24952	0x838420		4885c9			TESTQ CX, CX																			
  checker.go:24952	0x838423		7475			JE 0x83849a																			
  checker.go:24946	0x838425		4889442418		MOVQ AX, 0x18(SP)																		
  checker.go:24952	0x83842a		48894c2420		MOVQ CX, 0x20(SP)																		
  checker.go:24953	0x83842f		90			NOPL																				
  tracer.go:354		0x838430		488d0509665e00		LEAQ 0x5e6609(IP), AX																		
  tracer.go:354		0x838437		e804bbbeff		CALL runtime.newobject(SB)																	
  tracer.go:354		0x83843c		833dcd006c0100		CMPL runtime.writeBarrier(SB), $0x0																
  tracer.go:354		0x838443		7507			JNE 0x83844c																			
  tracer.go:354		0x838445		488b542418		MOVQ 0x18(SP), DX																		
  tracer.go:354		0x83844a		eb0d			JMP 0x838459																			
  tracer.go:354		0x83844c		e88f90c5ff		CALL runtime.gcWriteBarrier1(SB)																
  tracer.go:354		0x838451		488b542418		MOVQ 0x18(SP), DX																		
  tracer.go:354		0x838456		498913			MOVQ DX, 0(R11)																			
  tracer.go:354		0x838459		488910			MOVQ DX, 0(AX)																			
  tracer.go:354		0x83845c		488b7220		MOVQ 0x20(DX), SI																		
  tracer.go:354		0x838460		833da9006c0100		CMPL runtime.writeBarrier(SB), $0x0																
  tracer.go:354		0x838467		7408			JE 0x838471																			
  tracer.go:354		0x838469		e87290c5ff		CALL runtime.gcWriteBarrier1(SB)																
  tracer.go:354		0x83846e		498933			MOVQ SI, 0(R11)																			
  tracer.go:354		0x838471		48897008		MOVQ SI, 0x8(AX)																		
  tracer.go:26		0x838475		488b542420		MOVQ 0x20(SP), DX																		
  tracer.go:26		0x83847a		488b7208		MOVQ 0x8(DX), SI																		
  tracer.go:26		0x83847e		488b5210		MOVQ 0x10(DX), DX																		
  tracer.go:26		0x838482		488b7620		MOVQ 0x20(SI), SI																		
  tracer.go:26		0x838486		488d1d7332d100		LEAQ go:itab.*github.com/microsoft/typescript-go/internal/checker.tracedTypeAdapter,github.com/microsoft/typescript-go/internal/tracing.TracedType(SB), BX	
  tracer.go:26		0x83848d		4889c1			MOVQ AX, CX																			
  tracer.go:26		0x838490		4889d0			MOVQ DX, AX																			
  tracer.go:26		0x838493		ffd6			CALL SI																				
  checker.go:24955	0x838495		488b442418		MOVQ 0x18(SP), AX																		
  checker.go:24955	0x83849a		4883c428		ADDQ $0x28, SP																			
  checker.go:24955	0x83849e		5d			POPQ BP																				
  checker.go:24955	0x83849f		90			NOPL																				
  checker.go:24955	0x8384a0		c3			RET																				
  checker.go:24944	0x8384a1		4889442408		MOVQ AX, 0x8(SP)																		
  checker.go:24944	0x8384a6		895c2410		MOVL BX, 0x10(SP)																		
  checker.go:24944	0x8384aa		894c2414		MOVL CX, 0x14(SP)																		
  checker.go:24944	0x8384ae		48897c2418		MOVQ DI, 0x18(SP)																		
  checker.go:24944	0x8384b3		4889742420		MOVQ SI, 0x20(SP)																		
  checker.go:24944	0x8384b8		e84375c5ff		CALL runtime.morestack_noctxt.abi0(SB)																
  checker.go:24944	0x8384bd		488b442408		MOVQ 0x8(SP), AX																		
  checker.go:24944	0x8384c2		8b5c2410		MOVL 0x10(SP), BX																		
  checker.go:24944	0x8384c6		8b4c2414		MOVL 0x14(SP), CX																		
  checker.go:24944	0x8384ca		488b7c2418		MOVQ 0x18(SP), DI																		
  checker.go:24944	0x8384cf		488b742420		MOVQ 0x20(SP), SI																		
  checker.go:24944	0x8384d4		e9a7feffff		JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).newType(SB)											

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).Get(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:80	0x903740		493b6610		CMPQ SP, 0x10(R14)																																																																																																																						
  pointerlinkstore.go:80	0x903744		0f867c000000		JBE 0x9037c6																																																																																																																							
  pointerlinkstore.go:80	0x90374a		55			PUSHQ BP																																																																																																																							
  pointerlinkstore.go:80	0x90374b		4889e5			MOVQ SP, BP																																																																																																																							
  pointerlinkstore.go:80	0x90374e		4883ec20		SUBQ $0x20, SP																																																																																																																							
  pointerlinkstore.go:82	0x903752		4883780800		CMPQ 0x8(AX), $0x0																																																																																																																						
  pointerlinkstore.go:82	0x903757		7505			JNE 0x90375e																																																																																																																							
  pointerlinkstore.go:82	0x903759		4531c0			XORL R8, R8																																																																																																																							
  pointerlinkstore.go:82	0x90375c		eb48			JMP 0x9037a6																																																																																																																							
  pointerlinkstore.go:82	0x90375e		4889442430		MOVQ AX, 0x30(SP)																																																																																																																						
  pointerlinkstore.go:82	0x903763		48895c2438		MOVQ BX, 0x38(SP)																																																																																																																						
  pointerlinkstore.go:82	0x903768		48894c2440		MOVQ CX, 0x40(SP)																																																																																																																						
  pointerlinkstore.go:83	0x90376d		488b5b20		MOVQ 0x20(BX), BX																																																																																																																						
  pointerlinkstore.go:83	0x903771		e8ea030000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).slot(SB)	
  pointerlinkstore.go:84	0x903776		488b542430		MOVQ 0x30(SP), DX																																																																																																																						
  pointerlinkstore.go:84	0x90377b		488b7208		MOVQ 0x8(DX), SI																																																																																																																						
  pointerlinkstore.go:84	0x90377f		90			NOPL																																																																																																																								
  pointerlinkstore.go:84	0x903780		4839f0			CMPQ AX, SI																																																																																																																							
  pointerlinkstore.go:84	0x903783		7339			JAE 0x9037be																																																																																																																							
  pointerlinkstore.go:84	0x903785		488b32			MOVQ 0(DX), SI																																																																																																																							
  pointerlinkstore.go:84	0x903788		4989c0			MOVQ AX, R8																																																																																																																							
  pointerlinkstore.go:84	0x90378b		48c1e004		SHLQ $0x4, AX																																																																																																																							
  pointerlinkstore.go:84	0x90378f		488b440608		MOVQ 0x8(SI)(AX*1), AX																																																																																																																						
  pointerlinkstore.go:84	0x903794		4885c0			TESTQ AX, AX																																																																																																																							
  pointerlinkstore.go:84	0x903797		751f			JNE 0x9037b8																																																																																																																							
  pointerlinkstore.go:88	0x903799		4889d0			MOVQ DX, AX																																																																																																																							
  pointerlinkstore.go:88	0x90379c		488b4c2440		MOVQ 0x40(SP), CX																																																																																																																						
  pointerlinkstore.go:88	0x9037a1		488b5c2438		MOVQ 0x38(SP), BX																																																																																																																						
  pointerlinkstore.go:88	0x9037a6		488b5b20		MOVQ 0x20(BX), BX																																																																																																																						
  pointerlinkstore.go:88	0x9037aa		4c89c7			MOVQ R8, DI																																																																																																																							
  pointerlinkstore.go:88	0x9037ad		e84e000000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).insertAt(SB)	
  pointerlinkstore.go:88	0x9037b2		4883c420		ADDQ $0x20, SP																																																																																																																							
  pointerlinkstore.go:88	0x9037b6		5d			POPQ BP																																																																																																																								
  pointerlinkstore.go:88	0x9037b7		c3			RET																																																																																																																								
  pointerlinkstore.go:85	0x9037b8		4883c420		ADDQ $0x20, SP																																																																																																																							
  pointerlinkstore.go:85	0x9037bc		5d			POPQ BP																																																																																																																								
  pointerlinkstore.go:85	0x9037bd		c3			RET																																																																																																																								
  pointerlinkstore.go:84	0x9037be		6690			NOPW																																																																																																																								
  pointerlinkstore.go:84	0x9037c0		e8dbe0b8ff		CALL runtime.panicBounds(SB)																																																																																																																					
  pointerlinkstore.go:84	0x9037c5		90			NOPL																																																																																																																								
  pointerlinkstore.go:80	0x9037c6		4889442408		MOVQ AX, 0x8(SP)																																																																																																																						
  pointerlinkstore.go:80	0x9037cb		48895c2410		MOVQ BX, 0x10(SP)																																																																																																																						
  pointerlinkstore.go:80	0x9037d0		48894c2418		MOVQ CX, 0x18(SP)																																																																																																																						
  pointerlinkstore.go:80	0x9037d5		e826c2b8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																																																				
  pointerlinkstore.go:80	0x9037da		488b442408		MOVQ 0x8(SP), AX																																																																																																																						
  pointerlinkstore.go:80	0x9037df		488b5c2410		MOVQ 0x10(SP), BX																																																																																																																						
  pointerlinkstore.go:80	0x9037e4		488b4c2418		MOVQ 0x18(SP), CX																																																																																																																						
  pointerlinkstore.go:80	0x9037e9		e952ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).Get(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0x903b60		493b6610		CMPQ SP, 0x10(R14)																																																																																																																						
  pointerlinkstore.go:31	0x903b64		0f86a8000000		JBE 0x903c12																																																																																																																							
  pointerlinkstore.go:31	0x903b6a		55			PUSHQ BP																																																																																																																							
  pointerlinkstore.go:31	0x903b6b		4889e5			MOVQ SP, BP																																																																																																																							
  pointerlinkstore.go:31	0x903b6e		4883ec10		SUBQ $0x10, SP																																																																																																																							
  pointerlinkstore.go:32	0x903b72		488b5008		MOVQ 0x8(AX), DX																																																																																																																						
  pointerlinkstore.go:32	0x903b76		488d72ff		LEAQ -0x1(DX), SI																																																																																																																						
  pointerlinkstore.go:25	0x903b7a		4889cf			MOVQ CX, DI																																																																																																																							
  pointerlinkstore.go:26	0x903b7d		4989c8			MOVQ CX, R8																																																																																																																							
  pointerlinkstore.go:26	0x903b80		48c1e91e		SHRQ $0x1e, CX																																																																																																																							
  pointerlinkstore.go:26	0x903b84		4c31c1			XORQ R8, CX																																																																																																																							
  pointerlinkstore.go:26	0x903b87		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																																																																																																																					
  pointerlinkstore.go:26	0x903b91		4c0fafc1		IMULQ CX, R8																																																																																																																							
  pointerlinkstore.go:27	0x903b95		4c89c1			MOVQ R8, CX																																																																																																																							
  pointerlinkstore.go:27	0x903b98		49c1e81b		SHRQ $0x1b, R8																																																																																																																							
  pointerlinkstore.go:27	0x903b9c		4931c8			XORQ CX, R8																																																																																																																							
  pointerlinkstore.go:27	0x903b9f		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																																																																																																																					
  pointerlinkstore.go:27	0x903ba9		490fafc8		IMULQ R8, CX																																																																																																																							
  pointerlinkstore.go:28	0x903bad		4989c8			MOVQ CX, R8																																																																																																																							
  pointerlinkstore.go:28	0x903bb0		48c1e91f		SHRQ $0x1f, CX																																																																																																																							
  pointerlinkstore.go:28	0x903bb4		4c31c1			XORQ R8, CX																																																																																																																							
  pointerlinkstore.go:32	0x903bb7		4c8b00			MOVQ 0(AX), R8																																																																																																																							
  pointerlinkstore.go:33	0x903bba		4821f1			ANDQ SI, CX																																																																																																																							
  pointerlinkstore.go:33	0x903bbd		31c0			XORL AX, AX																																																																																																																							
  pointerlinkstore.go:33	0x903bbf		90			NOPL																																																																																																																								
  pointerlinkstore.go:34	0x903bc0		eb0a			JMP 0x903bcc																																																																																																																							
  pointerlinkstore.go:39	0x903bc2		498d4901		LEAQ 0x1(R9), CX																																																																																																																						
  pointerlinkstore.go:39	0x903bc6		4821f1			ANDQ SI, CX																																																																																																																							
  pointerlinkstore.go:34	0x903bc9		48ffc0			INCQ AX																																																																																																																								
  pointerlinkstore.go:34	0x903bcc		4839d0			CMPQ AX, DX																																																																																																																							
  pointerlinkstore.go:34	0x903bcf		7d2d			JGE 0x903bfe																																																																																																																							
  pointerlinkstore.go:35	0x903bd1		4839d1			CMPQ CX, DX																																																																																																																							
  pointerlinkstore.go:35	0x903bd4		7323			JAE 0x903bf9																																																																																																																							
  pointerlinkstore.go:35	0x903bd6		4989c9			MOVQ CX, R9																																																																																																																							
  pointerlinkstore.go:35	0x903bd9		48c1e104		SHLQ $0x4, CX																																																																																																																							
  pointerlinkstore.go:36	0x903bdd		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																																																																																																																						
  pointerlinkstore.go:36	0x903be2		4d85d2			TESTQ R10, R10																																																																																																																							
  pointerlinkstore.go:36	0x903be5		7409			JE 0x903bf0																																																																																																																							
  pointerlinkstore.go:36	0x903be7		498b0c08		MOVQ 0(R8)(CX*1), CX																																																																																																																						
  pointerlinkstore.go:36	0x903beb		4839f9			CMPQ CX, DI																																																																																																																							
  pointerlinkstore.go:36	0x903bee		75d2			JNE 0x903bc2																																																																																																																							
  pointerlinkstore.go:37	0x903bf0		4c89c8			MOVQ R9, AX																																																																																																																							
  pointerlinkstore.go:37	0x903bf3		4883c410		ADDQ $0x10, SP																																																																																																																							
  pointerlinkstore.go:37	0x903bf7		5d			POPQ BP																																																																																																																								
  pointerlinkstore.go:37	0x903bf8		c3			RET																																																																																																																								
  pointerlinkstore.go:35	0x903bf9		e8a2dcb8ff		CALL runtime.panicBounds(SB)																																																																																																																					
  pointerlinkstore.go:41	0x903bfe		488d057bc84500		LEAQ 0x45c87b(IP), AX																																																																																																																						
  pointerlinkstore.go:41	0x903c05		488d1d94f1c100		LEAQ 0xc1f194(IP), BX																																																																																																																						
  pointerlinkstore.go:41	0x903c0c		e88f5eb8ff		CALL runtime.gopanic(SB)																																																																																																																					
  pointerlinkstore.go:41	0x903c11		90			NOPL																																																																																																																								
  pointerlinkstore.go:31	0x903c12		4889442408		MOVQ AX, 0x8(SP)																																																																																																																						
  pointerlinkstore.go:31	0x903c17		48895c2410		MOVQ BX, 0x10(SP)																																																																																																																						
  pointerlinkstore.go:31	0x903c1c		48894c2418		MOVQ CX, 0x18(SP)																																																																																																																						
  pointerlinkstore.go:31	0x903c21		e8dabdb8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																																																				
  pointerlinkstore.go:31	0x903c26		488b442408		MOVQ 0x8(SP), AX																																																																																																																						
  pointerlinkstore.go:31	0x903c2b		488b5c2410		MOVQ 0x10(SP), BX																																																																																																																						
  pointerlinkstore.go:31	0x903c30		488b4c2418		MOVQ 0x18(SP), CX																																																																																																																						
  pointerlinkstore.go:31	0x903c35		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).slot(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).Get(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:80	0x903d40		493b6610		CMPQ SP, 0x10(R14)																																																																																				
  pointerlinkstore.go:80	0x903d44		0f867c000000		JBE 0x903dc6																																																																																					
  pointerlinkstore.go:80	0x903d4a		55			PUSHQ BP																																																																																					
  pointerlinkstore.go:80	0x903d4b		4889e5			MOVQ SP, BP																																																																																					
  pointerlinkstore.go:80	0x903d4e		4883ec20		SUBQ $0x20, SP																																																																																					
  pointerlinkstore.go:82	0x903d52		4883780800		CMPQ 0x8(AX), $0x0																																																																																				
  pointerlinkstore.go:82	0x903d57		7505			JNE 0x903d5e																																																																																					
  pointerlinkstore.go:82	0x903d59		4531c0			XORL R8, R8																																																																																					
  pointerlinkstore.go:82	0x903d5c		eb48			JMP 0x903da6																																																																																					
  pointerlinkstore.go:82	0x903d5e		4889442430		MOVQ AX, 0x30(SP)																																																																																				
  pointerlinkstore.go:82	0x903d63		48895c2438		MOVQ BX, 0x38(SP)																																																																																				
  pointerlinkstore.go:82	0x903d68		48894c2440		MOVQ CX, 0x40(SP)																																																																																				
  pointerlinkstore.go:83	0x903d6d		488b5b20		MOVQ 0x20(BX), BX																																																																																				
  pointerlinkstore.go:83	0x903d71		e8ea030000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).slot(SB)		
  pointerlinkstore.go:84	0x903d76		488b542430		MOVQ 0x30(SP), DX																																																																																				
  pointerlinkstore.go:84	0x903d7b		488b7208		MOVQ 0x8(DX), SI																																																																																				
  pointerlinkstore.go:84	0x903d7f		90			NOPL																																																																																						
  pointerlinkstore.go:84	0x903d80		4839f0			CMPQ AX, SI																																																																																					
  pointerlinkstore.go:84	0x903d83		7339			JAE 0x903dbe																																																																																					
  pointerlinkstore.go:84	0x903d85		488b32			MOVQ 0(DX), SI																																																																																					
  pointerlinkstore.go:84	0x903d88		4989c0			MOVQ AX, R8																																																																																					
  pointerlinkstore.go:84	0x903d8b		48c1e004		SHLQ $0x4, AX																																																																																					
  pointerlinkstore.go:84	0x903d8f		488b440608		MOVQ 0x8(SI)(AX*1), AX																																																																																				
  pointerlinkstore.go:84	0x903d94		4885c0			TESTQ AX, AX																																																																																					
  pointerlinkstore.go:84	0x903d97		751f			JNE 0x903db8																																																																																					
  pointerlinkstore.go:88	0x903d99		4889d0			MOVQ DX, AX																																																																																					
  pointerlinkstore.go:88	0x903d9c		488b4c2440		MOVQ 0x40(SP), CX																																																																																				
  pointerlinkstore.go:88	0x903da1		488b5c2438		MOVQ 0x38(SP), BX																																																																																				
  pointerlinkstore.go:88	0x903da6		488b5b20		MOVQ 0x20(BX), BX																																																																																				
  pointerlinkstore.go:88	0x903daa		4c89c7			MOVQ R8, DI																																																																																					
  pointerlinkstore.go:88	0x903dad		e84e000000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).insertAt(SB)	
  pointerlinkstore.go:88	0x903db2		4883c420		ADDQ $0x20, SP																																																																																					
  pointerlinkstore.go:88	0x903db6		5d			POPQ BP																																																																																						
  pointerlinkstore.go:88	0x903db7		c3			RET																																																																																						
  pointerlinkstore.go:85	0x903db8		4883c420		ADDQ $0x20, SP																																																																																					
  pointerlinkstore.go:85	0x903dbc		5d			POPQ BP																																																																																						
  pointerlinkstore.go:85	0x903dbd		c3			RET																																																																																						
  pointerlinkstore.go:84	0x903dbe		6690			NOPW																																																																																						
  pointerlinkstore.go:84	0x903dc0		e8dbdab8ff		CALL runtime.panicBounds(SB)																																																																																			
  pointerlinkstore.go:84	0x903dc5		90			NOPL																																																																																						
  pointerlinkstore.go:80	0x903dc6		4889442408		MOVQ AX, 0x8(SP)																																																																																				
  pointerlinkstore.go:80	0x903dcb		48895c2410		MOVQ BX, 0x10(SP)																																																																																				
  pointerlinkstore.go:80	0x903dd0		48894c2418		MOVQ CX, 0x18(SP)																																																																																				
  pointerlinkstore.go:80	0x903dd5		e826bcb8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																		
  pointerlinkstore.go:80	0x903dda		488b442408		MOVQ 0x8(SP), AX																																																																																				
  pointerlinkstore.go:80	0x903ddf		488b5c2410		MOVQ 0x10(SP), BX																																																																																				
  pointerlinkstore.go:80	0x903de4		488b4c2418		MOVQ 0x18(SP), CX																																																																																				
  pointerlinkstore.go:80	0x903de9		e952ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).Get(SB)		

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0x904160		493b6610		CMPQ SP, 0x10(R14)																																																																																			
  pointerlinkstore.go:31	0x904164		0f86a8000000		JBE 0x904212																																																																																				
  pointerlinkstore.go:31	0x90416a		55			PUSHQ BP																																																																																				
  pointerlinkstore.go:31	0x90416b		4889e5			MOVQ SP, BP																																																																																				
  pointerlinkstore.go:31	0x90416e		4883ec10		SUBQ $0x10, SP																																																																																				
  pointerlinkstore.go:32	0x904172		488b5008		MOVQ 0x8(AX), DX																																																																																			
  pointerlinkstore.go:32	0x904176		488d72ff		LEAQ -0x1(DX), SI																																																																																			
  pointerlinkstore.go:25	0x90417a		4889cf			MOVQ CX, DI																																																																																				
  pointerlinkstore.go:26	0x90417d		4989c8			MOVQ CX, R8																																																																																				
  pointerlinkstore.go:26	0x904180		48c1e91e		SHRQ $0x1e, CX																																																																																				
  pointerlinkstore.go:26	0x904184		4c31c1			XORQ R8, CX																																																																																				
  pointerlinkstore.go:26	0x904187		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																																																																																		
  pointerlinkstore.go:26	0x904191		4c0fafc1		IMULQ CX, R8																																																																																				
  pointerlinkstore.go:27	0x904195		4c89c1			MOVQ R8, CX																																																																																				
  pointerlinkstore.go:27	0x904198		49c1e81b		SHRQ $0x1b, R8																																																																																				
  pointerlinkstore.go:27	0x90419c		4931c8			XORQ CX, R8																																																																																				
  pointerlinkstore.go:27	0x90419f		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																																																																																		
  pointerlinkstore.go:27	0x9041a9		490fafc8		IMULQ R8, CX																																																																																				
  pointerlinkstore.go:28	0x9041ad		4989c8			MOVQ CX, R8																																																																																				
  pointerlinkstore.go:28	0x9041b0		48c1e91f		SHRQ $0x1f, CX																																																																																				
  pointerlinkstore.go:28	0x9041b4		4c31c1			XORQ R8, CX																																																																																				
  pointerlinkstore.go:32	0x9041b7		4c8b00			MOVQ 0(AX), R8																																																																																				
  pointerlinkstore.go:33	0x9041ba		4821f1			ANDQ SI, CX																																																																																				
  pointerlinkstore.go:33	0x9041bd		31c0			XORL AX, AX																																																																																				
  pointerlinkstore.go:33	0x9041bf		90			NOPL																																																																																					
  pointerlinkstore.go:34	0x9041c0		eb0a			JMP 0x9041cc																																																																																				
  pointerlinkstore.go:39	0x9041c2		498d4901		LEAQ 0x1(R9), CX																																																																																			
  pointerlinkstore.go:39	0x9041c6		4821f1			ANDQ SI, CX																																																																																				
  pointerlinkstore.go:34	0x9041c9		48ffc0			INCQ AX																																																																																					
  pointerlinkstore.go:34	0x9041cc		4839d0			CMPQ AX, DX																																																																																				
  pointerlinkstore.go:34	0x9041cf		7d2d			JGE 0x9041fe																																																																																				
  pointerlinkstore.go:35	0x9041d1		4839d1			CMPQ CX, DX																																																																																				
  pointerlinkstore.go:35	0x9041d4		7323			JAE 0x9041f9																																																																																				
  pointerlinkstore.go:35	0x9041d6		4989c9			MOVQ CX, R9																																																																																				
  pointerlinkstore.go:35	0x9041d9		48c1e104		SHLQ $0x4, CX																																																																																				
  pointerlinkstore.go:36	0x9041dd		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																																																																																			
  pointerlinkstore.go:36	0x9041e2		4d85d2			TESTQ R10, R10																																																																																				
  pointerlinkstore.go:36	0x9041e5		7409			JE 0x9041f0																																																																																				
  pointerlinkstore.go:36	0x9041e7		498b0c08		MOVQ 0(R8)(CX*1), CX																																																																																			
  pointerlinkstore.go:36	0x9041eb		4839f9			CMPQ CX, DI																																																																																				
  pointerlinkstore.go:36	0x9041ee		75d2			JNE 0x9041c2																																																																																				
  pointerlinkstore.go:37	0x9041f0		4c89c8			MOVQ R9, AX																																																																																				
  pointerlinkstore.go:37	0x9041f3		4883c410		ADDQ $0x10, SP																																																																																				
  pointerlinkstore.go:37	0x9041f7		5d			POPQ BP																																																																																					
  pointerlinkstore.go:37	0x9041f8		c3			RET																																																																																					
  pointerlinkstore.go:35	0x9041f9		e8a2d6b8ff		CALL runtime.panicBounds(SB)																																																																																		
  pointerlinkstore.go:41	0x9041fe		488d057bc24500		LEAQ 0x45c27b(IP), AX																																																																																			
  pointerlinkstore.go:41	0x904205		488d1d94ebc100		LEAQ 0xc1eb94(IP), BX																																																																																			
  pointerlinkstore.go:41	0x90420c		e88f58b8ff		CALL runtime.gopanic(SB)																																																																																		
  pointerlinkstore.go:41	0x904211		90			NOPL																																																																																					
  pointerlinkstore.go:31	0x904212		4889442408		MOVQ AX, 0x8(SP)																																																																																			
  pointerlinkstore.go:31	0x904217		48895c2410		MOVQ BX, 0x10(SP)																																																																																			
  pointerlinkstore.go:31	0x90421c		48894c2418		MOVQ CX, 0x18(SP)																																																																																			
  pointerlinkstore.go:31	0x904221		e8dab7b8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																	
  pointerlinkstore.go:31	0x904226		488b442408		MOVQ 0x8(SP), AX																																																																																			
  pointerlinkstore.go:31	0x90422b		488b5c2410		MOVQ 0x10(SP), BX																																																																																			
  pointerlinkstore.go:31	0x904230		488b4c2418		MOVQ 0x18(SP), CX																																																																																			
  pointerlinkstore.go:31	0x904235		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).slot(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).Get(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:80	0x9043c0		493b6610		CMPQ SP, 0x10(R14)																																																																																																				
  pointerlinkstore.go:80	0x9043c4		0f867c000000		JBE 0x904446																																																																																																					
  pointerlinkstore.go:80	0x9043ca		55			PUSHQ BP																																																																																																					
  pointerlinkstore.go:80	0x9043cb		4889e5			MOVQ SP, BP																																																																																																					
  pointerlinkstore.go:80	0x9043ce		4883ec20		SUBQ $0x20, SP																																																																																																					
  pointerlinkstore.go:82	0x9043d2		4883780800		CMPQ 0x8(AX), $0x0																																																																																																				
  pointerlinkstore.go:82	0x9043d7		7505			JNE 0x9043de																																																																																																					
  pointerlinkstore.go:82	0x9043d9		4531c0			XORL R8, R8																																																																																																					
  pointerlinkstore.go:82	0x9043dc		eb48			JMP 0x904426																																																																																																					
  pointerlinkstore.go:82	0x9043de		4889442430		MOVQ AX, 0x30(SP)																																																																																																				
  pointerlinkstore.go:82	0x9043e3		48895c2438		MOVQ BX, 0x38(SP)																																																																																																				
  pointerlinkstore.go:82	0x9043e8		48894c2440		MOVQ CX, 0x40(SP)																																																																																																				
  pointerlinkstore.go:83	0x9043ed		488b5b20		MOVQ 0x20(BX), BX																																																																																																				
  pointerlinkstore.go:83	0x9043f1		e8ea030000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).slot(SB)	
  pointerlinkstore.go:84	0x9043f6		488b542430		MOVQ 0x30(SP), DX																																																																																																				
  pointerlinkstore.go:84	0x9043fb		488b7208		MOVQ 0x8(DX), SI																																																																																																				
  pointerlinkstore.go:84	0x9043ff		90			NOPL																																																																																																						
  pointerlinkstore.go:84	0x904400		4839f0			CMPQ AX, SI																																																																																																					
  pointerlinkstore.go:84	0x904403		7339			JAE 0x90443e																																																																																																					
  pointerlinkstore.go:84	0x904405		488b32			MOVQ 0(DX), SI																																																																																																					
  pointerlinkstore.go:84	0x904408		4989c0			MOVQ AX, R8																																																																																																					
  pointerlinkstore.go:84	0x90440b		48c1e004		SHLQ $0x4, AX																																																																																																					
  pointerlinkstore.go:84	0x90440f		488b440608		MOVQ 0x8(SI)(AX*1), AX																																																																																																				
  pointerlinkstore.go:84	0x904414		4885c0			TESTQ AX, AX																																																																																																					
  pointerlinkstore.go:84	0x904417		751f			JNE 0x904438																																																																																																					
  pointerlinkstore.go:88	0x904419		4889d0			MOVQ DX, AX																																																																																																					
  pointerlinkstore.go:88	0x90441c		488b4c2440		MOVQ 0x40(SP), CX																																																																																																				
  pointerlinkstore.go:88	0x904421		488b5c2438		MOVQ 0x38(SP), BX																																																																																																				
  pointerlinkstore.go:88	0x904426		488b5b20		MOVQ 0x20(BX), BX																																																																																																				
  pointerlinkstore.go:88	0x90442a		4c89c7			MOVQ R8, DI																																																																																																					
  pointerlinkstore.go:88	0x90442d		e84e000000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).insertAt(SB)	
  pointerlinkstore.go:88	0x904432		4883c420		ADDQ $0x20, SP																																																																																																					
  pointerlinkstore.go:88	0x904436		5d			POPQ BP																																																																																																						
  pointerlinkstore.go:88	0x904437		c3			RET																																																																																																						
  pointerlinkstore.go:85	0x904438		4883c420		ADDQ $0x20, SP																																																																																																					
  pointerlinkstore.go:85	0x90443c		5d			POPQ BP																																																																																																						
  pointerlinkstore.go:85	0x90443d		c3			RET																																																																																																						
  pointerlinkstore.go:84	0x90443e		6690			NOPW																																																																																																						
  pointerlinkstore.go:84	0x904440		e85bd4b8ff		CALL runtime.panicBounds(SB)																																																																																																			
  pointerlinkstore.go:84	0x904445		90			NOPL																																																																																																						
  pointerlinkstore.go:80	0x904446		4889442408		MOVQ AX, 0x8(SP)																																																																																																				
  pointerlinkstore.go:80	0x90444b		48895c2410		MOVQ BX, 0x10(SP)																																																																																																				
  pointerlinkstore.go:80	0x904450		48894c2418		MOVQ CX, 0x18(SP)																																																																																																				
  pointerlinkstore.go:80	0x904455		e8a6b5b8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																																		
  pointerlinkstore.go:80	0x90445a		488b442408		MOVQ 0x8(SP), AX																																																																																																				
  pointerlinkstore.go:80	0x90445f		488b5c2410		MOVQ 0x10(SP), BX																																																																																																				
  pointerlinkstore.go:80	0x904464		488b4c2418		MOVQ 0x18(SP), CX																																																																																																				
  pointerlinkstore.go:80	0x904469		e952ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).Get(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0x9047e0		493b6610		CMPQ SP, 0x10(R14)																																																																																																				
  pointerlinkstore.go:31	0x9047e4		0f86a8000000		JBE 0x904892																																																																																																					
  pointerlinkstore.go:31	0x9047ea		55			PUSHQ BP																																																																																																					
  pointerlinkstore.go:31	0x9047eb		4889e5			MOVQ SP, BP																																																																																																					
  pointerlinkstore.go:31	0x9047ee		4883ec10		SUBQ $0x10, SP																																																																																																					
  pointerlinkstore.go:32	0x9047f2		488b5008		MOVQ 0x8(AX), DX																																																																																																				
  pointerlinkstore.go:32	0x9047f6		488d72ff		LEAQ -0x1(DX), SI																																																																																																				
  pointerlinkstore.go:25	0x9047fa		4889cf			MOVQ CX, DI																																																																																																					
  pointerlinkstore.go:26	0x9047fd		4989c8			MOVQ CX, R8																																																																																																					
  pointerlinkstore.go:26	0x904800		48c1e91e		SHRQ $0x1e, CX																																																																																																					
  pointerlinkstore.go:26	0x904804		4c31c1			XORQ R8, CX																																																																																																					
  pointerlinkstore.go:26	0x904807		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																																																																																																			
  pointerlinkstore.go:26	0x904811		4c0fafc1		IMULQ CX, R8																																																																																																					
  pointerlinkstore.go:27	0x904815		4c89c1			MOVQ R8, CX																																																																																																					
  pointerlinkstore.go:27	0x904818		49c1e81b		SHRQ $0x1b, R8																																																																																																					
  pointerlinkstore.go:27	0x90481c		4931c8			XORQ CX, R8																																																																																																					
  pointerlinkstore.go:27	0x90481f		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																																																																																																			
  pointerlinkstore.go:27	0x904829		490fafc8		IMULQ R8, CX																																																																																																					
  pointerlinkstore.go:28	0x90482d		4989c8			MOVQ CX, R8																																																																																																					
  pointerlinkstore.go:28	0x904830		48c1e91f		SHRQ $0x1f, CX																																																																																																					
  pointerlinkstore.go:28	0x904834		4c31c1			XORQ R8, CX																																																																																																					
  pointerlinkstore.go:32	0x904837		4c8b00			MOVQ 0(AX), R8																																																																																																					
  pointerlinkstore.go:33	0x90483a		4821f1			ANDQ SI, CX																																																																																																					
  pointerlinkstore.go:33	0x90483d		31c0			XORL AX, AX																																																																																																					
  pointerlinkstore.go:33	0x90483f		90			NOPL																																																																																																						
  pointerlinkstore.go:34	0x904840		eb0a			JMP 0x90484c																																																																																																					
  pointerlinkstore.go:39	0x904842		498d4901		LEAQ 0x1(R9), CX																																																																																																				
  pointerlinkstore.go:39	0x904846		4821f1			ANDQ SI, CX																																																																																																					
  pointerlinkstore.go:34	0x904849		48ffc0			INCQ AX																																																																																																						
  pointerlinkstore.go:34	0x90484c		4839d0			CMPQ AX, DX																																																																																																					
  pointerlinkstore.go:34	0x90484f		7d2d			JGE 0x90487e																																																																																																					
  pointerlinkstore.go:35	0x904851		4839d1			CMPQ CX, DX																																																																																																					
  pointerlinkstore.go:35	0x904854		7323			JAE 0x904879																																																																																																					
  pointerlinkstore.go:35	0x904856		4989c9			MOVQ CX, R9																																																																																																					
  pointerlinkstore.go:35	0x904859		48c1e104		SHLQ $0x4, CX																																																																																																					
  pointerlinkstore.go:36	0x90485d		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																																																																																																				
  pointerlinkstore.go:36	0x904862		4d85d2			TESTQ R10, R10																																																																																																					
  pointerlinkstore.go:36	0x904865		7409			JE 0x904870																																																																																																					
  pointerlinkstore.go:36	0x904867		498b0c08		MOVQ 0(R8)(CX*1), CX																																																																																																				
  pointerlinkstore.go:36	0x90486b		4839f9			CMPQ CX, DI																																																																																																					
  pointerlinkstore.go:36	0x90486e		75d2			JNE 0x904842																																																																																																					
  pointerlinkstore.go:37	0x904870		4c89c8			MOVQ R9, AX																																																																																																					
  pointerlinkstore.go:37	0x904873		4883c410		ADDQ $0x10, SP																																																																																																					
  pointerlinkstore.go:37	0x904877		5d			POPQ BP																																																																																																						
  pointerlinkstore.go:37	0x904878		c3			RET																																																																																																						
  pointerlinkstore.go:35	0x904879		e822d0b8ff		CALL runtime.panicBounds(SB)																																																																																																			
  pointerlinkstore.go:41	0x90487e		488d05fbbb4500		LEAQ 0x45bbfb(IP), AX																																																																																																				
  pointerlinkstore.go:41	0x904885		488d1d14e5c100		LEAQ 0xc1e514(IP), BX																																																																																																				
  pointerlinkstore.go:41	0x90488c		e80f52b8ff		CALL runtime.gopanic(SB)																																																																																																			
  pointerlinkstore.go:41	0x904891		90			NOPL																																																																																																						
  pointerlinkstore.go:31	0x904892		4889442408		MOVQ AX, 0x8(SP)																																																																																																				
  pointerlinkstore.go:31	0x904897		48895c2410		MOVQ BX, 0x10(SP)																																																																																																				
  pointerlinkstore.go:31	0x90489c		48894c2418		MOVQ CX, 0x18(SP)																																																																																																				
  pointerlinkstore.go:31	0x9048a1		e85ab1b8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																																		
  pointerlinkstore.go:31	0x9048a6		488b442408		MOVQ 0x8(SP), AX																																																																																																				
  pointerlinkstore.go:31	0x9048ab		488b5c2410		MOVQ 0x10(SP), BX																																																																																																				
  pointerlinkstore.go:31	0x9048b0		488b4c2418		MOVQ 0x18(SP), CX																																																																																																				
  pointerlinkstore.go:31	0x9048b5		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).slot(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).Get(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:80	0x905800		493b6610		CMPQ SP, 0x10(R14)																												
  pointerlinkstore.go:80	0x905804		0f867c000000		JBE 0x905886																													
  pointerlinkstore.go:80	0x90580a		55			PUSHQ BP																													
  pointerlinkstore.go:80	0x90580b		4889e5			MOVQ SP, BP																													
  pointerlinkstore.go:80	0x90580e		4883ec20		SUBQ $0x20, SP																													
  pointerlinkstore.go:82	0x905812		4883780800		CMPQ 0x8(AX), $0x0																												
  pointerlinkstore.go:82	0x905817		7505			JNE 0x90581e																													
  pointerlinkstore.go:82	0x905819		4531c0			XORL R8, R8																													
  pointerlinkstore.go:82	0x90581c		eb48			JMP 0x905866																													
  pointerlinkstore.go:82	0x90581e		4889442430		MOVQ AX, 0x30(SP)																												
  pointerlinkstore.go:82	0x905823		48895c2438		MOVQ BX, 0x38(SP)																												
  pointerlinkstore.go:82	0x905828		48894c2440		MOVQ CX, 0x40(SP)																												
  pointerlinkstore.go:83	0x90582d		488b5b20		MOVQ 0x20(BX), BX																												
  pointerlinkstore.go:83	0x905831		e8ea030000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB)		
  pointerlinkstore.go:84	0x905836		488b542430		MOVQ 0x30(SP), DX																												
  pointerlinkstore.go:84	0x90583b		488b7208		MOVQ 0x8(DX), SI																												
  pointerlinkstore.go:84	0x90583f		90			NOPL																														
  pointerlinkstore.go:84	0x905840		4839f0			CMPQ AX, SI																													
  pointerlinkstore.go:84	0x905843		7339			JAE 0x90587e																													
  pointerlinkstore.go:84	0x905845		488b32			MOVQ 0(DX), SI																													
  pointerlinkstore.go:84	0x905848		4989c0			MOVQ AX, R8																													
  pointerlinkstore.go:84	0x90584b		48c1e004		SHLQ $0x4, AX																													
  pointerlinkstore.go:84	0x90584f		488b440608		MOVQ 0x8(SI)(AX*1), AX																												
  pointerlinkstore.go:84	0x905854		4885c0			TESTQ AX, AX																													
  pointerlinkstore.go:84	0x905857		751f			JNE 0x905878																													
  pointerlinkstore.go:88	0x905859		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:88	0x90585c		488b4c2440		MOVQ 0x40(SP), CX																												
  pointerlinkstore.go:88	0x905861		488b5c2438		MOVQ 0x38(SP), BX																												
  pointerlinkstore.go:88	0x905866		488b5b20		MOVQ 0x20(BX), BX																												
  pointerlinkstore.go:88	0x90586a		4c89c7			MOVQ R8, DI																													
  pointerlinkstore.go:88	0x90586d		e84e000000		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).insertAt(SB)	
  pointerlinkstore.go:88	0x905872		4883c420		ADDQ $0x20, SP																													
  pointerlinkstore.go:88	0x905876		5d			POPQ BP																														
  pointerlinkstore.go:88	0x905877		c3			RET																														
  pointerlinkstore.go:85	0x905878		4883c420		ADDQ $0x20, SP																													
  pointerlinkstore.go:85	0x90587c		5d			POPQ BP																														
  pointerlinkstore.go:85	0x90587d		c3			RET																														
  pointerlinkstore.go:84	0x90587e		6690			NOPW																														
  pointerlinkstore.go:84	0x905880		e81bc0b8ff		CALL runtime.panicBounds(SB)																											
  pointerlinkstore.go:84	0x905885		90			NOPL																														
  pointerlinkstore.go:80	0x905886		4889442408		MOVQ AX, 0x8(SP)																												
  pointerlinkstore.go:80	0x90588b		48895c2410		MOVQ BX, 0x10(SP)																												
  pointerlinkstore.go:80	0x905890		48894c2418		MOVQ CX, 0x18(SP)																												
  pointerlinkstore.go:80	0x905895		e866a1b8ff		CALL runtime.morestack_noctxt.abi0(SB)																										
  pointerlinkstore.go:80	0x90589a		488b442408		MOVQ 0x8(SP), AX																												
  pointerlinkstore.go:80	0x90589f		488b5c2410		MOVQ 0x10(SP), BX																												
  pointerlinkstore.go:80	0x9058a4		488b4c2418		MOVQ 0x18(SP), CX																												
  pointerlinkstore.go:80	0x9058a9		e952ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).Get(SB)		

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0x905c20		493b6610		CMPQ SP, 0x10(R14)																											
  pointerlinkstore.go:31	0x905c24		0f86a8000000		JBE 0x905cd2																												
  pointerlinkstore.go:31	0x905c2a		55			PUSHQ BP																												
  pointerlinkstore.go:31	0x905c2b		4889e5			MOVQ SP, BP																												
  pointerlinkstore.go:31	0x905c2e		4883ec10		SUBQ $0x10, SP																												
  pointerlinkstore.go:32	0x905c32		488b5008		MOVQ 0x8(AX), DX																											
  pointerlinkstore.go:32	0x905c36		488d72ff		LEAQ -0x1(DX), SI																											
  pointerlinkstore.go:25	0x905c3a		4889cf			MOVQ CX, DI																												
  pointerlinkstore.go:26	0x905c3d		4989c8			MOVQ CX, R8																												
  pointerlinkstore.go:26	0x905c40		48c1e91e		SHRQ $0x1e, CX																												
  pointerlinkstore.go:26	0x905c44		4c31c1			XORQ R8, CX																												
  pointerlinkstore.go:26	0x905c47		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																										
  pointerlinkstore.go:26	0x905c51		4c0fafc1		IMULQ CX, R8																												
  pointerlinkstore.go:27	0x905c55		4c89c1			MOVQ R8, CX																												
  pointerlinkstore.go:27	0x905c58		49c1e81b		SHRQ $0x1b, R8																												
  pointerlinkstore.go:27	0x905c5c		4931c8			XORQ CX, R8																												
  pointerlinkstore.go:27	0x905c5f		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																										
  pointerlinkstore.go:27	0x905c69		490fafc8		IMULQ R8, CX																												
  pointerlinkstore.go:28	0x905c6d		4989c8			MOVQ CX, R8																												
  pointerlinkstore.go:28	0x905c70		48c1e91f		SHRQ $0x1f, CX																												
  pointerlinkstore.go:28	0x905c74		4c31c1			XORQ R8, CX																												
  pointerlinkstore.go:32	0x905c77		4c8b00			MOVQ 0(AX), R8																												
  pointerlinkstore.go:33	0x905c7a		4821f1			ANDQ SI, CX																												
  pointerlinkstore.go:33	0x905c7d		31c0			XORL AX, AX																												
  pointerlinkstore.go:33	0x905c7f		90			NOPL																													
  pointerlinkstore.go:34	0x905c80		eb0a			JMP 0x905c8c																												
  pointerlinkstore.go:39	0x905c82		498d4901		LEAQ 0x1(R9), CX																											
  pointerlinkstore.go:39	0x905c86		4821f1			ANDQ SI, CX																												
  pointerlinkstore.go:34	0x905c89		48ffc0			INCQ AX																													
  pointerlinkstore.go:34	0x905c8c		4839d0			CMPQ AX, DX																												
  pointerlinkstore.go:34	0x905c8f		7d2d			JGE 0x905cbe																												
  pointerlinkstore.go:35	0x905c91		4839d1			CMPQ CX, DX																												
  pointerlinkstore.go:35	0x905c94		7323			JAE 0x905cb9																												
  pointerlinkstore.go:35	0x905c96		4989c9			MOVQ CX, R9																												
  pointerlinkstore.go:35	0x905c99		48c1e104		SHLQ $0x4, CX																												
  pointerlinkstore.go:36	0x905c9d		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																											
  pointerlinkstore.go:36	0x905ca2		4d85d2			TESTQ R10, R10																												
  pointerlinkstore.go:36	0x905ca5		7409			JE 0x905cb0																												
  pointerlinkstore.go:36	0x905ca7		498b0c08		MOVQ 0(R8)(CX*1), CX																											
  pointerlinkstore.go:36	0x905cab		4839f9			CMPQ CX, DI																												
  pointerlinkstore.go:36	0x905cae		75d2			JNE 0x905c82																												
  pointerlinkstore.go:37	0x905cb0		4c89c8			MOVQ R9, AX																												
  pointerlinkstore.go:37	0x905cb3		4883c410		ADDQ $0x10, SP																												
  pointerlinkstore.go:37	0x905cb7		5d			POPQ BP																													
  pointerlinkstore.go:37	0x905cb8		c3			RET																													
  pointerlinkstore.go:35	0x905cb9		e8e2bbb8ff		CALL runtime.panicBounds(SB)																										
  pointerlinkstore.go:41	0x905cbe		488d05bba74500		LEAQ 0x45a7bb(IP), AX																											
  pointerlinkstore.go:41	0x905cc5		488d1dd4d0c100		LEAQ 0xc1d0d4(IP), BX																											
  pointerlinkstore.go:41	0x905ccc		e8cf3db8ff		CALL runtime.gopanic(SB)																										
  pointerlinkstore.go:41	0x905cd1		90			NOPL																													
  pointerlinkstore.go:31	0x905cd2		4889442408		MOVQ AX, 0x8(SP)																											
  pointerlinkstore.go:31	0x905cd7		48895c2410		MOVQ BX, 0x10(SP)																											
  pointerlinkstore.go:31	0x905cdc		48894c2418		MOVQ CX, 0x18(SP)																											
  pointerlinkstore.go:31	0x905ce1		e81a9db8ff		CALL runtime.morestack_noctxt.abi0(SB)																									
  pointerlinkstore.go:31	0x905ce6		488b442408		MOVQ 0x8(SP), AX																											
  pointerlinkstore.go:31	0x905ceb		488b5c2410		MOVQ 0x10(SP), BX																											
  pointerlinkstore.go:31	0x905cf0		488b4c2418		MOVQ 0x18(SP), CX																											
  pointerlinkstore.go:31	0x905cf5		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB)	
