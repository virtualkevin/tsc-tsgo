TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbol(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:16409		0x888be0		493b6610		CMPQ SP, 0x10(R14)																												
  checker.go:16409		0x888be4		0f8683020000		JBE 0x888e6d																													
  checker.go:16409		0x888bea		55			PUSHQ BP																													
  checker.go:16409		0x888beb		4889e5			MOVQ SP, BP																													
  checker.go:16409		0x888bee		4883ec38		SUBQ $0x38, SP																													
  checker.go:16410		0x888bf2		8b5304			MOVL 0x4(BX), DX																												
  checker.go:16410		0x888bf5		0fbae210		BTL $0x10, DX																													
  checker.go:16410		0x888bf9		0f8258020000		JB 0x888e57																													
  checker.go:16413		0x888bff		0fbae200		BTL $0x0, DX																													
  checker.go:16413		0x888c03		0f8243020000		JB 0x888e4c																													
  checker.go:16416		0x888c09		0fbae212		BTL $0x12, DX																													
  checker.go:16416		0x888c0d		0f822e020000		JB 0x888e41																													
  checker.go:16419		0x888c13		0fbae20d		BTL $0xd, DX																													
  checker.go:16419		0x888c17		0f8219020000		JB 0x888e36																													
  checker.go:16422		0x888c1d		8b13			MOVL 0(BX), DX																													
  checker.go:16422		0x888c1f		90			NOPL																														
  checker.go:16422		0x888c20		f7c200800100		TESTL $0x18000, DX																												
  checker.go:16422		0x888c26		0f85ff010000		JNE 0x888e2b																													
  checker.go:16425		0x888c2c		f7c207000000		TESTL $0x7, DX																													
  checker.go:16425		0x888c32		0f85e4010000		JNE 0x888e1c																													
  checker.go:16410		0x888c38		4889442448		MOVQ AX, 0x48(SP)																												
  checker.go:16410		0x888c3d		48895c2450		MOVQ BX, 0x50(SP)																												
  checker.go:16428		0x888c42		f7c2b0230000		TESTL $0x23b0, DX																												
  checker.go:16428		0x888c48		0f84d3000000		JE 0x888d21																													
  checker.go:16821		0x888c4e		488d9040090000		LEAQ 0x940(AX), DX																												
  checker.go:16821		0x888c55		4883b84809000000	CMPQ 0x948(AX), $0x0																												
  pointerlinkstore.go:82	0x888c5d		7505			JNE 0x888c64																													
  pointerlinkstore.go:82	0x888c5f		4531c0			XORL R8, R8																													
  pointerlinkstore.go:82	0x888c62		eb51			JMP 0x888cb5																													
  checker.go:16821		0x888c64		4889542430		MOVQ DX, 0x30(SP)																												
  pointerlinkstore.go:83	0x888c69		488d353073e700		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), SI				
  pointerlinkstore.go:83	0x888c70		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:83	0x888c73		4889d9			MOVQ BX, CX																													
  pointerlinkstore.go:83	0x888c76		4889f3			MOVQ SI, BX																													
  pointerlinkstore.go:83	0x888c79		e862ca1700		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB)		
  pointerlinkstore.go:84	0x888c7e		488b542448		MOVQ 0x48(SP), DX																												
  pointerlinkstore.go:84	0x888c83		488bb248090000		MOVQ 0x948(DX), SI																												
  pointerlinkstore.go:84	0x888c8a		4839f0			CMPQ AX, SI																													
  pointerlinkstore.go:84	0x888c8d		0f83d4010000		JAE 0x888e67																													
  pointerlinkstore.go:84	0x888c93		488bb240090000		MOVQ 0x940(DX), SI																												
  pointerlinkstore.go:84	0x888c9a		4989c0			MOVQ AX, R8																													
  pointerlinkstore.go:84	0x888c9d		48c1e004		SHLQ $0x4, AX																													
  pointerlinkstore.go:84	0x888ca1		488b743008		MOVQ 0x8(AX)(SI*1), SI																												
  pointerlinkstore.go:84	0x888ca6		4885f6			TESTQ SI, SI																													
  pointerlinkstore.go:84	0x888ca9		752a			JNE 0x888cd5																													
  pointerlinkstore.go:88	0x888cab		488b542430		MOVQ 0x30(SP), DX																												
  pointerlinkstore.go:88	0x888cb0		488b5c2450		MOVQ 0x50(SP), BX																												
  pointerlinkstore.go:88	0x888cb5		488d35e472e700		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), SI				
  pointerlinkstore.go:88	0x888cbc		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:88	0x888cbf		4889d9			MOVQ BX, CX																													
  pointerlinkstore.go:88	0x888cc2		4c89c7			MOVQ R8, DI																													
  pointerlinkstore.go:88	0x888cc5		4889f3			MOVQ SI, BX																													
  pointerlinkstore.go:88	0x888cc8		e853c51700		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).insertAt(SB)	
  checker.go:16823		0x888ccd		488b542448		MOVQ 0x48(SP), DX																												
  checker.go:16821		0x888cd2		4889c6			MOVQ AX, SI																													
  checker.go:16822		0x888cd5		48833e00		CMPQ 0(SI), $0x0																												
  checker.go:16822		0x888cd9		753c			JNE 0x888d17																													
  checker.go:16821		0x888cdb		4889742428		MOVQ SI, 0x28(SP)																												
  checker.go:16823		0x888ce0		4889d0			MOVQ DX, AX																													
  checker.go:16823		0x888ce3		488b5c2450		MOVQ 0x50(SP), BX																												
  checker.go:16823		0x888ce8		e8733b0000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfFuncClassEnumModuleWorker(SB)																	
  checker.go:16823		0x888ced		833d7c1b9a0100		CMPL runtime.writeBarrier(SB), $0x0																										
  checker.go:16823		0x888cf4		7507			JNE 0x888cfd																													
  checker.go:16823		0x888cf6		488b4c2428		MOVQ 0x28(SP), CX																												
  checker.go:16823		0x888cfb		eb14			JMP 0x888d11																													
  checker.go:16823		0x888cfd		488b4c2428		MOVQ 0x28(SP), CX																												
  checker.go:16823		0x888d02		488b11			MOVQ 0(CX), DX																													
  checker.go:16823		0x888d05		e8f687c0ff		CALL runtime.gcWriteBarrier2(SB)																										
  checker.go:16823		0x888d0a		498903			MOVQ AX, 0(R11)																													
  checker.go:16823		0x888d0d		49895308		MOVQ DX, 0x8(R11)																												
  checker.go:16823		0x888d11		488901			MOVQ AX, 0(CX)																													
  checker.go:16825		0x888d14		4889ce			MOVQ CX, SI																													
  checker.go:16825		0x888d17		488b06			MOVQ 0(SI), AX																													
  checker.go:16429		0x888d1a		4883c438		ADDQ $0x38, SP																													
  checker.go:16429		0x888d1e		5d			POPQ BP																														
  checker.go:16429		0x888d1f		90			NOPL																														
  checker.go:16429		0x888d20		c3			RET																														
  checker.go:16431		0x888d21		0fbae203		BTL $0x3, DX																													
  checker.go:16431		0x888d25		0f83d3000000		JAE 0x888dfe																													
  checker.go:18380		0x888d2b		488d9040090000		LEAQ 0x940(AX), DX																												
  checker.go:18380		0x888d32		4883b84809000000	CMPQ 0x948(AX), $0x0																												
  pointerlinkstore.go:82	0x888d3a		7506			JNE 0x888d42																													
  pointerlinkstore.go:82	0x888d3c		4531c0			XORL R8, R8																													
  pointerlinkstore.go:82	0x888d3f		90			NOPL																														
  pointerlinkstore.go:82	0x888d40		eb51			JMP 0x888d93																													
  checker.go:18380		0x888d42		4889542430		MOVQ DX, 0x30(SP)																												
  pointerlinkstore.go:83	0x888d47		488d355272e700		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), SI				
  pointerlinkstore.go:83	0x888d4e		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:83	0x888d51		4889d9			MOVQ BX, CX																													
  pointerlinkstore.go:83	0x888d54		4889f3			MOVQ SI, BX																													
  pointerlinkstore.go:83	0x888d57		e884c91700		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB)		
  pointerlinkstore.go:84	0x888d5c		488b542448		MOVQ 0x48(SP), DX																												
  pointerlinkstore.go:84	0x888d61		488bb248090000		MOVQ 0x948(DX), SI																												
  pointerlinkstore.go:84	0x888d68		4839f0			CMPQ AX, SI																													
  pointerlinkstore.go:84	0x888d6b		0f83f1000000		JAE 0x888e62																													
  pointerlinkstore.go:84	0x888d71		488bb240090000		MOVQ 0x940(DX), SI																												
  pointerlinkstore.go:84	0x888d78		4989c0			MOVQ AX, R8																													
  pointerlinkstore.go:84	0x888d7b		48c1e004		SHLQ $0x4, AX																													
  pointerlinkstore.go:84	0x888d7f		488b743008		MOVQ 0x8(AX)(SI*1), SI																												
  pointerlinkstore.go:84	0x888d84		4885f6			TESTQ SI, SI																													
  pointerlinkstore.go:84	0x888d87		752a			JNE 0x888db3																													
  pointerlinkstore.go:88	0x888d89		488b542430		MOVQ 0x30(SP), DX																												
  pointerlinkstore.go:88	0x888d8e		488b5c2450		MOVQ 0x50(SP), BX																												
  pointerlinkstore.go:88	0x888d93		488d350672e700		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), SI				
  pointerlinkstore.go:88	0x888d9a		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:88	0x888d9d		4889d9			MOVQ BX, CX																													
  pointerlinkstore.go:88	0x888da0		4c89c7			MOVQ R8, DI																													
  pointerlinkstore.go:88	0x888da3		4889f3			MOVQ SI, BX																													
  pointerlinkstore.go:88	0x888da6		e875c41700		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).insertAt(SB)	
  checker.go:18382		0x888dab		488b542448		MOVQ 0x48(SP), DX																												
  checker.go:18380		0x888db0		4889c6			MOVQ AX, SI																													
  checker.go:18381		0x888db3		48833e00		CMPQ 0(SI), $0x0																												
  checker.go:18381		0x888db7		753c			JNE 0x888df5																													
  checker.go:18380		0x888db9		4889742420		MOVQ SI, 0x20(SP)																												
  checker.go:18382		0x888dbe		4889d0			MOVQ DX, AX																													
  checker.go:18382		0x888dc1		488b5c2450		MOVQ 0x50(SP), BX																												
  checker.go:18382		0x888dc6		e855590400		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getDeclaredTypeOfEnumMember(SB)																		
  checker.go:18382		0x888dcb		833d9e1a9a0100		CMPL runtime.writeBarrier(SB), $0x0																										
  checker.go:18382		0x888dd2		7507			JNE 0x888ddb																													
  checker.go:18382		0x888dd4		488b4c2420		MOVQ 0x20(SP), CX																												
  checker.go:18382		0x888dd9		eb14			JMP 0x888def																													
  checker.go:18382		0x888ddb		488b4c2420		MOVQ 0x20(SP), CX																												
  checker.go:18382		0x888de0		488b11			MOVQ 0(CX), DX																													
  checker.go:18382		0x888de3		e81887c0ff		CALL runtime.gcWriteBarrier2(SB)																										
  checker.go:18382		0x888de8		498903			MOVQ AX, 0(R11)																													
  checker.go:18382		0x888deb		49895308		MOVQ DX, 0x8(R11)																												
  checker.go:18382		0x888def		488901			MOVQ AX, 0(CX)																													
  checker.go:18384		0x888df2		4889ce			MOVQ CX, SI																													
  checker.go:18384		0x888df5		488b06			MOVQ 0(SI), AX																													
  checker.go:16432		0x888df8		4883c438		ADDQ $0x38, SP																													
  checker.go:16432		0x888dfc		5d			POPQ BP																														
  checker.go:16432		0x888dfd		c3			RET																														
  checker.go:16434		0x888dfe		0fbae215		BTL $0x15, DX																													
  checker.go:16434		0x888e02		730b			JAE 0x888e0f																													
  checker.go:16435		0x888e04		e8f72f0100		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfAlias(SB)																				
  checker.go:16435		0x888e09		4883c438		ADDQ $0x38, SP																													
  checker.go:16435		0x888e0d		5d			POPQ BP																														
  checker.go:16435		0x888e0e		c3			RET																														
  checker.go:16437		0x888e0f		488b80900b0000		MOVQ 0xb90(AX), AX																												
  checker.go:16437		0x888e16		4883c438		ADDQ $0x38, SP																													
  checker.go:16437		0x888e1a		5d			POPQ BP																														
  checker.go:16437		0x888e1b		c3			RET																														
  checker.go:16437		0x888e1c		0f1f4000		NOPL 0(AX)																													
  checker.go:16426		0x888e20		e8fb020000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfVariableOrParameterOrProperty(SB)																	
  checker.go:16426		0x888e25		4883c438		ADDQ $0x38, SP																													
  checker.go:16426		0x888e29		5d			POPQ BP																														
  checker.go:16426		0x888e2a		c3			RET																														
  checker.go:16423		0x888e2b		e8b01b0100		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfAccessors(SB)																			
  checker.go:16423		0x888e30		4883c438		ADDQ $0x38, SP																													
  checker.go:16423		0x888e34		5d			POPQ BP																														
  checker.go:16423		0x888e35		c3			RET																														
  checker.go:16420		0x888e36		e885610d00		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfReverseMappedSymbol(SB)																		
  checker.go:16420		0x888e3b		4883c438		ADDQ $0x38, SP																													
  checker.go:16420		0x888e3f		5d			POPQ BP																														
  checker.go:16420		0x888e40		c3			RET																														
  checker.go:16417		0x888e41		e83a980200		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfMappedSymbol(SB)																			
  checker.go:16417		0x888e46		4883c438		ADDQ $0x38, SP																													
  checker.go:16417		0x888e4a		5d			POPQ BP																														
  checker.go:16417		0x888e4b		c3			RET																														
  checker.go:16414		0x888e4c		e84f000000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfInstantiatedSymbol(SB)																		
  checker.go:16414		0x888e51		4883c438		ADDQ $0x38, SP																													
  checker.go:16414		0x888e55		5d			POPQ BP																														
  checker.go:16414		0x888e56		c3			RET																														
  checker.go:16411		0x888e57		e8e4edffff		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbolWithDeferredType(SB)																		
  checker.go:16411		0x888e5c		4883c438		ADDQ $0x38, SP																													
  checker.go:16411		0x888e60		5d			POPQ BP																														
  checker.go:16411		0x888e61		c3			RET																														
  pointerlinkstore.go:84	0x888e62		e8398ac0ff		CALL runtime.panicBounds(SB)																											
  pointerlinkstore.go:84	0x888e67		e8348ac0ff		CALL runtime.panicBounds(SB)																											
  pointerlinkstore.go:84	0x888e6c		90			NOPL																														
  checker.go:16409		0x888e6d		4889442408		MOVQ AX, 0x8(SP)																												
  checker.go:16409		0x888e72		48895c2410		MOVQ BX, 0x10(SP)																												
  checker.go:16409		0x888e77		e8846bc0ff		CALL runtime.morestack_noctxt.abi0(SB)																										
  checker.go:16409		0x888e7c		488b442408		MOVQ 0x8(SP), AX																												
  checker.go:16409		0x888e81		488b5c2410		MOVQ 0x10(SP), BX																												
  checker.go:16409		0x888e86		e955fdffff		JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbol(SB)																				

TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfInstantiatedSymbol(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:16444		0x888ea0		493b6610		CMPQ SP, 0x10(R14)																												
  checker.go:16444		0x888ea4		0f860d010000		JBE 0x888fb7																													
  checker.go:16444		0x888eaa		55			PUSHQ BP																													
  checker.go:16444		0x888eab		4889e5			MOVQ SP, BP																													
  checker.go:16444		0x888eae		4883ec30		SUBQ $0x30, SP																													
  pointerlinkstore.go:82	0x888eb2		4889442440		MOVQ AX, 0x40(SP)																												
  checker.go:16445		0x888eb7		488d9040090000		LEAQ 0x940(AX), DX																												
  checker.go:16445		0x888ebe		4883b84809000000	CMPQ 0x948(AX), $0x0																												
  pointerlinkstore.go:82	0x888ec6		7505			JNE 0x888ecd																													
  pointerlinkstore.go:82	0x888ec8		4531c0			XORL R8, R8																													
  pointerlinkstore.go:82	0x888ecb		eb62			JMP 0x888f2f																													
  pointerlinkstore.go:82	0x888ecd		48895c2448		MOVQ BX, 0x48(SP)																												
  checker.go:16445		0x888ed2		4889542428		MOVQ DX, 0x28(SP)																												
  pointerlinkstore.go:83	0x888ed7		488d35c270e700		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), SI				
  pointerlinkstore.go:83	0x888ede		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:83	0x888ee1		4889d9			MOVQ BX, CX																													
  pointerlinkstore.go:83	0x888ee4		4889f3			MOVQ SI, BX																													
  pointerlinkstore.go:83	0x888ee7		e8f4c71700		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB)		
  pointerlinkstore.go:84	0x888eec		488b542440		MOVQ 0x40(SP), DX																												
  pointerlinkstore.go:84	0x888ef1		488bb248090000		MOVQ 0x948(DX), SI																												
  pointerlinkstore.go:84	0x888ef8		0f1f840000000000	NOPL 0(AX)(AX*1)																												
  pointerlinkstore.go:84	0x888f00		4839f0			CMPQ AX, SI																													
  pointerlinkstore.go:84	0x888f03		0f83a8000000		JAE 0x888fb1																													
  pointerlinkstore.go:84	0x888f09		488bb240090000		MOVQ 0x940(DX), SI																												
  pointerlinkstore.go:84	0x888f10		4989c0			MOVQ AX, R8																													
  pointerlinkstore.go:84	0x888f13		48c1e004		SHLQ $0x4, AX																													
  pointerlinkstore.go:84	0x888f17		488b740608		MOVQ 0x8(SI)(AX*1), SI																												
  pointerlinkstore.go:84	0x888f1c		0f1f4000		NOPL 0(AX)																													
  pointerlinkstore.go:84	0x888f20		4885f6			TESTQ SI, SI																													
  pointerlinkstore.go:84	0x888f23		752a			JNE 0x888f4f																													
  pointerlinkstore.go:88	0x888f25		488b542428		MOVQ 0x28(SP), DX																												
  pointerlinkstore.go:88	0x888f2a		488b5c2448		MOVQ 0x48(SP), BX																												
  pointerlinkstore.go:88	0x888f2f		488d356a70e700		LEAQ github.com/microsoft/typescript-go/internal/core..dict.PointerLinkStore[github.com/microsoft/typescript-go/internal/ast.Symbol,github.com/microsoft/typescript-go/internal/checker.ValueSymbolLinks](SB), SI				
  pointerlinkstore.go:88	0x888f36		4889d0			MOVQ DX, AX																													
  pointerlinkstore.go:88	0x888f39		4889d9			MOVQ BX, CX																													
  pointerlinkstore.go:88	0x888f3c		4c89c7			MOVQ R8, DI																													
  pointerlinkstore.go:88	0x888f3f		4889f3			MOVQ SI, BX																													
  pointerlinkstore.go:88	0x888f42		e8d9c21700		CALL github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).insertAt(SB)	
  checker.go:16447		0x888f47		488b542440		MOVQ 0x40(SP), DX																												
  checker.go:16445		0x888f4c		4889c6			MOVQ AX, SI																													
  checker.go:16446		0x888f4f		48833e00		CMPQ 0(SI), $0x0																												
  checker.go:16446		0x888f53		7553			JNE 0x888fa8																													
  checker.go:16445		0x888f55		4889742420		MOVQ SI, 0x20(SP)																												
  checker.go:16447		0x888f5a		488b5e10		MOVQ 0x10(SI), BX																												
  checker.go:16447		0x888f5e		4889d0			MOVQ DX, AX																													
  checker.go:16447		0x888f61		e87afcffff		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfSymbol(SB)																				
  checker.go:16447		0x888f66		488b4c2420		MOVQ 0x20(SP), CX																												
  checker.go:16447		0x888f6b		488b4918		MOVQ 0x18(CX), CX																												
  checker.go:21998		0x888f6f		4889c3			MOVQ AX, BX																													
  checker.go:21998		0x888f72		31ff			XORL DI, DI																													
  checker.go:21998		0x888f74		488b442440		MOVQ 0x40(SP), AX																												
  checker.go:21998		0x888f79		e8c2450300		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateTypeWithAlias(SB)																		
  checker.go:16447		0x888f7e		833deb189a0100		CMPL runtime.writeBarrier(SB), $0x0																										
  checker.go:16447		0x888f85		7507			JNE 0x888f8e																													
  checker.go:16447		0x888f87		488b4c2420		MOVQ 0x20(SP), CX																												
  checker.go:16447		0x888f8c		eb14			JMP 0x888fa2																													
  checker.go:16447		0x888f8e		488b4c2420		MOVQ 0x20(SP), CX																												
  checker.go:16447		0x888f93		488b11			MOVQ 0(CX), DX																													
  checker.go:16447		0x888f96		e86585c0ff		CALL runtime.gcWriteBarrier2(SB)																										
  checker.go:16447		0x888f9b		498903			MOVQ AX, 0(R11)																													
  checker.go:16447		0x888f9e		49895308		MOVQ DX, 0x8(R11)																												
  checker.go:16447		0x888fa2		488901			MOVQ AX, 0(CX)																													
  checker.go:16449		0x888fa5		4889ce			MOVQ CX, SI																													
  checker.go:16449		0x888fa8		488b06			MOVQ 0(SI), AX																													
  checker.go:16449		0x888fab		4883c430		ADDQ $0x30, SP																													
  checker.go:16449		0x888faf		5d			POPQ BP																														
  checker.go:16449		0x888fb0		c3			RET																														
  pointerlinkstore.go:84	0x888fb1		e8ea88c0ff		CALL runtime.panicBounds(SB)																											
  pointerlinkstore.go:84	0x888fb6		90			NOPL																														
  checker.go:16444		0x888fb7		4889442408		MOVQ AX, 0x8(SP)																												
  checker.go:16444		0x888fbc		48895c2410		MOVQ BX, 0x10(SP)																												
  checker.go:16444		0x888fc1		e83a6ac0ff		CALL runtime.morestack_noctxt.abi0(SB)																										
  checker.go:16444		0x888fc6		488b442408		MOVQ 0x8(SP), AX																												
  checker.go:16444		0x888fcb		488b5c2410		MOVQ 0x10(SP), BX																												
  checker.go:16444		0x888fd0		e9cbfeffff		JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).getTypeOfInstantiatedSymbol(SB)																		

TEXT github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateType(SB) github.com/microsoft/typescript-go/internal/checker/checker.go
  checker.go:21997	0x8bd4e0		493b6610		CMPQ SP, 0x10(R14)											
  checker.go:21997	0x8bd4e4		7615			JBE 0x8bd4fb												
  checker.go:21997	0x8bd4e6		55			PUSHQ BP												
  checker.go:21997	0x8bd4e7		4889e5			MOVQ SP, BP												
  checker.go:21997	0x8bd4ea		4883ec20		SUBQ $0x20, SP												
  checker.go:21998	0x8bd4ee		31ff			XORL DI, DI												
  checker.go:21998	0x8bd4f0		e84b000000		CALL github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateTypeWithAlias(SB)	
  checker.go:21998	0x8bd4f5		4883c420		ADDQ $0x20, SP												
  checker.go:21998	0x8bd4f9		5d			POPQ BP													
  checker.go:21998	0x8bd4fa		c3			RET													
  checker.go:21997	0x8bd4fb		4889442408		MOVQ AX, 0x8(SP)											
  checker.go:21997	0x8bd500		48895c2410		MOVQ BX, 0x10(SP)											
  checker.go:21997	0x8bd505		48894c2418		MOVQ CX, 0x18(SP)											
  checker.go:21997	0x8bd50a		e8f124bdff		CALL runtime.morestack_noctxt.abi0(SB)									
  checker.go:21997	0x8bd50f		488b442408		MOVQ 0x8(SP), AX											
  checker.go:21997	0x8bd514		488b5c2410		MOVQ 0x10(SP), BX											
  checker.go:21997	0x8bd519		488b4c2418		MOVQ 0x18(SP), CX											
  checker.go:21997	0x8bd51e		6690			NOPW													
  checker.go:21997	0x8bd520		ebbe			JMP github.com/microsoft/typescript-go/internal/checker.(*Checker).instantiateType(SB)			

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0xa03c80		493b6610		CMPQ SP, 0x10(R14)																																																																																																																						
  pointerlinkstore.go:31	0xa03c84		0f86a8000000		JBE 0xa03d32																																																																																																																							
  pointerlinkstore.go:31	0xa03c8a		55			PUSHQ BP																																																																																																																							
  pointerlinkstore.go:31	0xa03c8b		4889e5			MOVQ SP, BP																																																																																																																							
  pointerlinkstore.go:31	0xa03c8e		4883ec10		SUBQ $0x10, SP																																																																																																																							
  pointerlinkstore.go:32	0xa03c92		488b5008		MOVQ 0x8(AX), DX																																																																																																																						
  pointerlinkstore.go:32	0xa03c96		488d72ff		LEAQ -0x1(DX), SI																																																																																																																						
  pointerlinkstore.go:25	0xa03c9a		4889cf			MOVQ CX, DI																																																																																																																							
  pointerlinkstore.go:26	0xa03c9d		4989c8			MOVQ CX, R8																																																																																																																							
  pointerlinkstore.go:26	0xa03ca0		48c1e91e		SHRQ $0x1e, CX																																																																																																																							
  pointerlinkstore.go:26	0xa03ca4		4c31c1			XORQ R8, CX																																																																																																																							
  pointerlinkstore.go:26	0xa03ca7		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																																																																																																																					
  pointerlinkstore.go:26	0xa03cb1		4c0fafc1		IMULQ CX, R8																																																																																																																							
  pointerlinkstore.go:27	0xa03cb5		4c89c1			MOVQ R8, CX																																																																																																																							
  pointerlinkstore.go:27	0xa03cb8		49c1e81b		SHRQ $0x1b, R8																																																																																																																							
  pointerlinkstore.go:27	0xa03cbc		4931c8			XORQ CX, R8																																																																																																																							
  pointerlinkstore.go:27	0xa03cbf		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																																																																																																																					
  pointerlinkstore.go:27	0xa03cc9		490fafc8		IMULQ R8, CX																																																																																																																							
  pointerlinkstore.go:28	0xa03ccd		4989c8			MOVQ CX, R8																																																																																																																							
  pointerlinkstore.go:28	0xa03cd0		48c1e91f		SHRQ $0x1f, CX																																																																																																																							
  pointerlinkstore.go:28	0xa03cd4		4c31c1			XORQ R8, CX																																																																																																																							
  pointerlinkstore.go:32	0xa03cd7		4c8b00			MOVQ 0(AX), R8																																																																																																																							
  pointerlinkstore.go:33	0xa03cda		4821f1			ANDQ SI, CX																																																																																																																							
  pointerlinkstore.go:33	0xa03cdd		31c0			XORL AX, AX																																																																																																																							
  pointerlinkstore.go:33	0xa03cdf		90			NOPL																																																																																																																								
  pointerlinkstore.go:34	0xa03ce0		eb0a			JMP 0xa03cec																																																																																																																							
  pointerlinkstore.go:39	0xa03ce2		498d4901		LEAQ 0x1(R9), CX																																																																																																																						
  pointerlinkstore.go:39	0xa03ce6		4821f1			ANDQ SI, CX																																																																																																																							
  pointerlinkstore.go:34	0xa03ce9		48ffc0			INCQ AX																																																																																																																								
  pointerlinkstore.go:34	0xa03cec		4839d0			CMPQ AX, DX																																																																																																																							
  pointerlinkstore.go:34	0xa03cef		7d2d			JGE 0xa03d1e																																																																																																																							
  pointerlinkstore.go:35	0xa03cf1		4839d1			CMPQ CX, DX																																																																																																																							
  pointerlinkstore.go:35	0xa03cf4		7323			JAE 0xa03d19																																																																																																																							
  pointerlinkstore.go:35	0xa03cf6		4989c9			MOVQ CX, R9																																																																																																																							
  pointerlinkstore.go:35	0xa03cf9		48c1e104		SHLQ $0x4, CX																																																																																																																							
  pointerlinkstore.go:36	0xa03cfd		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																																																																																																																						
  pointerlinkstore.go:36	0xa03d02		4d85d2			TESTQ R10, R10																																																																																																																							
  pointerlinkstore.go:36	0xa03d05		7409			JE 0xa03d10																																																																																																																							
  pointerlinkstore.go:36	0xa03d07		498b0c08		MOVQ 0(R8)(CX*1), CX																																																																																																																						
  pointerlinkstore.go:36	0xa03d0b		4839f9			CMPQ CX, DI																																																																																																																							
  pointerlinkstore.go:36	0xa03d0e		75d2			JNE 0xa03ce2																																																																																																																							
  pointerlinkstore.go:37	0xa03d10		4c89c8			MOVQ R9, AX																																																																																																																							
  pointerlinkstore.go:37	0xa03d13		4883c410		ADDQ $0x10, SP																																																																																																																							
  pointerlinkstore.go:37	0xa03d17		5d			POPQ BP																																																																																																																								
  pointerlinkstore.go:37	0xa03d18		c3			RET																																																																																																																								
  pointerlinkstore.go:35	0xa03d19		e882dba8ff		CALL runtime.panicBounds(SB)																																																																																																																					
  pointerlinkstore.go:41	0xa03d1e		488d05bb715100		LEAQ 0x5171bb(IP), AX																																																																																																																						
  pointerlinkstore.go:41	0xa03d25		488d1db464cd00		LEAQ 0xcd64b4(IP), BX																																																																																																																						
  pointerlinkstore.go:41	0xa03d2c		e86f5da8ff		CALL runtime.gopanic(SB)																																																																																																																					
  pointerlinkstore.go:41	0xa03d31		90			NOPL																																																																																																																								
  pointerlinkstore.go:31	0xa03d32		4889442408		MOVQ AX, 0x8(SP)																																																																																																																						
  pointerlinkstore.go:31	0xa03d37		48895c2410		MOVQ BX, 0x10(SP)																																																																																																																						
  pointerlinkstore.go:31	0xa03d3c		48894c2418		MOVQ CX, 0x18(SP)																																																																																																																						
  pointerlinkstore.go:31	0xa03d41		e8babca8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																																																				
  pointerlinkstore.go:31	0xa03d46		488b442408		MOVQ 0x8(SP), AX																																																																																																																						
  pointerlinkstore.go:31	0xa03d4b		488b5c2410		MOVQ 0x10(SP), BX																																																																																																																						
  pointerlinkstore.go:31	0xa03d50		488b4c2418		MOVQ 0x18(SP), CX																																																																																																																						
  pointerlinkstore.go:31	0xa03d55		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.effectsSignature *github.com/microsoft/typescript-go/internal/checker.Signature; github.com/microsoft/typescript-go/internal/checker.decoratorSignature *github.com/microsoft/typescript-go/internal/checker.Signature }]).slot(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0xa04320		493b6610		CMPQ SP, 0x10(R14)																																																																																			
  pointerlinkstore.go:31	0xa04324		0f86a8000000		JBE 0xa043d2																																																																																				
  pointerlinkstore.go:31	0xa0432a		55			PUSHQ BP																																																																																				
  pointerlinkstore.go:31	0xa0432b		4889e5			MOVQ SP, BP																																																																																				
  pointerlinkstore.go:31	0xa0432e		4883ec10		SUBQ $0x10, SP																																																																																				
  pointerlinkstore.go:32	0xa04332		488b5008		MOVQ 0x8(AX), DX																																																																																			
  pointerlinkstore.go:32	0xa04336		488d72ff		LEAQ -0x1(DX), SI																																																																																			
  pointerlinkstore.go:25	0xa0433a		4889cf			MOVQ CX, DI																																																																																				
  pointerlinkstore.go:26	0xa0433d		4989c8			MOVQ CX, R8																																																																																				
  pointerlinkstore.go:26	0xa04340		48c1e91e		SHRQ $0x1e, CX																																																																																				
  pointerlinkstore.go:26	0xa04344		4c31c1			XORQ R8, CX																																																																																				
  pointerlinkstore.go:26	0xa04347		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																																																																																		
  pointerlinkstore.go:26	0xa04351		4c0fafc1		IMULQ CX, R8																																																																																				
  pointerlinkstore.go:27	0xa04355		4c89c1			MOVQ R8, CX																																																																																				
  pointerlinkstore.go:27	0xa04358		49c1e81b		SHRQ $0x1b, R8																																																																																				
  pointerlinkstore.go:27	0xa0435c		4931c8			XORQ CX, R8																																																																																				
  pointerlinkstore.go:27	0xa0435f		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																																																																																		
  pointerlinkstore.go:27	0xa04369		490fafc8		IMULQ R8, CX																																																																																				
  pointerlinkstore.go:28	0xa0436d		4989c8			MOVQ CX, R8																																																																																				
  pointerlinkstore.go:28	0xa04370		48c1e91f		SHRQ $0x1f, CX																																																																																				
  pointerlinkstore.go:28	0xa04374		4c31c1			XORQ R8, CX																																																																																				
  pointerlinkstore.go:32	0xa04377		4c8b00			MOVQ 0(AX), R8																																																																																				
  pointerlinkstore.go:33	0xa0437a		4821f1			ANDQ SI, CX																																																																																				
  pointerlinkstore.go:33	0xa0437d		31c0			XORL AX, AX																																																																																				
  pointerlinkstore.go:33	0xa0437f		90			NOPL																																																																																					
  pointerlinkstore.go:34	0xa04380		eb0a			JMP 0xa0438c																																																																																				
  pointerlinkstore.go:39	0xa04382		498d4901		LEAQ 0x1(R9), CX																																																																																			
  pointerlinkstore.go:39	0xa04386		4821f1			ANDQ SI, CX																																																																																				
  pointerlinkstore.go:34	0xa04389		48ffc0			INCQ AX																																																																																					
  pointerlinkstore.go:34	0xa0438c		4839d0			CMPQ AX, DX																																																																																				
  pointerlinkstore.go:34	0xa0438f		7d2d			JGE 0xa043be																																																																																				
  pointerlinkstore.go:35	0xa04391		4839d1			CMPQ CX, DX																																																																																				
  pointerlinkstore.go:35	0xa04394		7323			JAE 0xa043b9																																																																																				
  pointerlinkstore.go:35	0xa04396		4989c9			MOVQ CX, R9																																																																																				
  pointerlinkstore.go:35	0xa04399		48c1e104		SHLQ $0x4, CX																																																																																				
  pointerlinkstore.go:36	0xa0439d		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																																																																																			
  pointerlinkstore.go:36	0xa043a2		4d85d2			TESTQ R10, R10																																																																																				
  pointerlinkstore.go:36	0xa043a5		7409			JE 0xa043b0																																																																																				
  pointerlinkstore.go:36	0xa043a7		498b0c08		MOVQ 0(R8)(CX*1), CX																																																																																			
  pointerlinkstore.go:36	0xa043ab		4839f9			CMPQ CX, DI																																																																																				
  pointerlinkstore.go:36	0xa043ae		75d2			JNE 0xa04382																																																																																				
  pointerlinkstore.go:37	0xa043b0		4c89c8			MOVQ R9, AX																																																																																				
  pointerlinkstore.go:37	0xa043b3		4883c410		ADDQ $0x10, SP																																																																																				
  pointerlinkstore.go:37	0xa043b7		5d			POPQ BP																																																																																					
  pointerlinkstore.go:37	0xa043b8		c3			RET																																																																																					
  pointerlinkstore.go:35	0xa043b9		e8e2d4a8ff		CALL runtime.panicBounds(SB)																																																																																		
  pointerlinkstore.go:41	0xa043be		488d051b6b5100		LEAQ 0x516b1b(IP), AX																																																																																			
  pointerlinkstore.go:41	0xa043c5		488d1d145ecd00		LEAQ 0xcd5e14(IP), BX																																																																																			
  pointerlinkstore.go:41	0xa043cc		e8cf56a8ff		CALL runtime.gopanic(SB)																																																																																		
  pointerlinkstore.go:41	0xa043d1		90			NOPL																																																																																					
  pointerlinkstore.go:31	0xa043d2		4889442408		MOVQ AX, 0x8(SP)																																																																																			
  pointerlinkstore.go:31	0xa043d7		48895c2410		MOVQ BX, 0x10(SP)																																																																																			
  pointerlinkstore.go:31	0xa043dc		48894c2418		MOVQ CX, 0x18(SP)																																																																																			
  pointerlinkstore.go:31	0xa043e1		e81ab6a8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																	
  pointerlinkstore.go:31	0xa043e6		488b442408		MOVQ 0x8(SP), AX																																																																																			
  pointerlinkstore.go:31	0xa043eb		488b5c2410		MOVQ 0x10(SP), BX																																																																																			
  pointerlinkstore.go:31	0xa043f0		488b4c2418		MOVQ 0x18(SP), CX																																																																																			
  pointerlinkstore.go:31	0xa043f5		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedSymbol *github.com/microsoft/typescript-go/internal/ast.Symbol }]).slot(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0xa049c0		493b6610		CMPQ SP, 0x10(R14)																																																																																																				
  pointerlinkstore.go:31	0xa049c4		0f86a8000000		JBE 0xa04a72																																																																																																					
  pointerlinkstore.go:31	0xa049ca		55			PUSHQ BP																																																																																																					
  pointerlinkstore.go:31	0xa049cb		4889e5			MOVQ SP, BP																																																																																																					
  pointerlinkstore.go:31	0xa049ce		4883ec10		SUBQ $0x10, SP																																																																																																					
  pointerlinkstore.go:32	0xa049d2		488b5008		MOVQ 0x8(AX), DX																																																																																																				
  pointerlinkstore.go:32	0xa049d6		488d72ff		LEAQ -0x1(DX), SI																																																																																																				
  pointerlinkstore.go:25	0xa049da		4889cf			MOVQ CX, DI																																																																																																					
  pointerlinkstore.go:26	0xa049dd		4989c8			MOVQ CX, R8																																																																																																					
  pointerlinkstore.go:26	0xa049e0		48c1e91e		SHRQ $0x1e, CX																																																																																																					
  pointerlinkstore.go:26	0xa049e4		4c31c1			XORQ R8, CX																																																																																																					
  pointerlinkstore.go:26	0xa049e7		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																																																																																																			
  pointerlinkstore.go:26	0xa049f1		4c0fafc1		IMULQ CX, R8																																																																																																					
  pointerlinkstore.go:27	0xa049f5		4c89c1			MOVQ R8, CX																																																																																																					
  pointerlinkstore.go:27	0xa049f8		49c1e81b		SHRQ $0x1b, R8																																																																																																					
  pointerlinkstore.go:27	0xa049fc		4931c8			XORQ CX, R8																																																																																																					
  pointerlinkstore.go:27	0xa049ff		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																																																																																																			
  pointerlinkstore.go:27	0xa04a09		490fafc8		IMULQ R8, CX																																																																																																					
  pointerlinkstore.go:28	0xa04a0d		4989c8			MOVQ CX, R8																																																																																																					
  pointerlinkstore.go:28	0xa04a10		48c1e91f		SHRQ $0x1f, CX																																																																																																					
  pointerlinkstore.go:28	0xa04a14		4c31c1			XORQ R8, CX																																																																																																					
  pointerlinkstore.go:32	0xa04a17		4c8b00			MOVQ 0(AX), R8																																																																																																					
  pointerlinkstore.go:33	0xa04a1a		4821f1			ANDQ SI, CX																																																																																																					
  pointerlinkstore.go:33	0xa04a1d		31c0			XORL AX, AX																																																																																																					
  pointerlinkstore.go:33	0xa04a1f		90			NOPL																																																																																																						
  pointerlinkstore.go:34	0xa04a20		eb0a			JMP 0xa04a2c																																																																																																					
  pointerlinkstore.go:39	0xa04a22		498d4901		LEAQ 0x1(R9), CX																																																																																																				
  pointerlinkstore.go:39	0xa04a26		4821f1			ANDQ SI, CX																																																																																																					
  pointerlinkstore.go:34	0xa04a29		48ffc0			INCQ AX																																																																																																						
  pointerlinkstore.go:34	0xa04a2c		4839d0			CMPQ AX, DX																																																																																																					
  pointerlinkstore.go:34	0xa04a2f		7d2d			JGE 0xa04a5e																																																																																																					
  pointerlinkstore.go:35	0xa04a31		4839d1			CMPQ CX, DX																																																																																																					
  pointerlinkstore.go:35	0xa04a34		7323			JAE 0xa04a59																																																																																																					
  pointerlinkstore.go:35	0xa04a36		4989c9			MOVQ CX, R9																																																																																																					
  pointerlinkstore.go:35	0xa04a39		48c1e104		SHLQ $0x4, CX																																																																																																					
  pointerlinkstore.go:36	0xa04a3d		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																																																																																																				
  pointerlinkstore.go:36	0xa04a42		4d85d2			TESTQ R10, R10																																																																																																					
  pointerlinkstore.go:36	0xa04a45		7409			JE 0xa04a50																																																																																																					
  pointerlinkstore.go:36	0xa04a47		498b0c08		MOVQ 0(R8)(CX*1), CX																																																																																																				
  pointerlinkstore.go:36	0xa04a4b		4839f9			CMPQ CX, DI																																																																																																					
  pointerlinkstore.go:36	0xa04a4e		75d2			JNE 0xa04a22																																																																																																					
  pointerlinkstore.go:37	0xa04a50		4c89c8			MOVQ R9, AX																																																																																																					
  pointerlinkstore.go:37	0xa04a53		4883c410		ADDQ $0x10, SP																																																																																																					
  pointerlinkstore.go:37	0xa04a57		5d			POPQ BP																																																																																																						
  pointerlinkstore.go:37	0xa04a58		c3			RET																																																																																																						
  pointerlinkstore.go:35	0xa04a59		e842cea8ff		CALL runtime.panicBounds(SB)																																																																																																			
  pointerlinkstore.go:41	0xa04a5e		488d057b645100		LEAQ 0x51647b(IP), AX																																																																																																				
  pointerlinkstore.go:41	0xa04a65		488d1d7457cd00		LEAQ 0xcd5774(IP), BX																																																																																																				
  pointerlinkstore.go:41	0xa04a6c		e82f50a8ff		CALL runtime.gopanic(SB)																																																																																																			
  pointerlinkstore.go:41	0xa04a71		90			NOPL																																																																																																						
  pointerlinkstore.go:31	0xa04a72		4889442408		MOVQ AX, 0x8(SP)																																																																																																				
  pointerlinkstore.go:31	0xa04a77		48895c2410		MOVQ BX, 0x10(SP)																																																																																																				
  pointerlinkstore.go:31	0xa04a7c		48894c2418		MOVQ CX, 0x18(SP)																																																																																																				
  pointerlinkstore.go:31	0xa04a81		e87aafa8ff		CALL runtime.morestack_noctxt.abi0(SB)																																																																																																		
  pointerlinkstore.go:31	0xa04a86		488b442408		MOVQ 0x8(SP), AX																																																																																																				
  pointerlinkstore.go:31	0xa04a8b		488b5c2410		MOVQ 0x10(SP), BX																																																																																																				
  pointerlinkstore.go:31	0xa04a90		488b4c2418		MOVQ 0x18(SP), CX																																																																																																				
  pointerlinkstore.go:31	0xa04a95		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.struct { Kind github.com/microsoft/typescript-go/internal/ast.Kind; Flags github.com/microsoft/typescript-go/internal/ast.NodeFlags; Loc github.com/microsoft/typescript-go/internal/core.TextRange; github.com/microsoft/typescript-go/internal/ast.id sync/atomic.Uint64; Parent *github.com/microsoft/typescript-go/internal/ast.Node; github.com/microsoft/typescript-go/internal/ast.data github.com/microsoft/typescript-go/internal/ast.nodeData },go.shape.struct { github.com/microsoft/typescript-go/internal/checker.resolvedType *github.com/microsoft/typescript-go/internal/checker.Type; github.com/microsoft/typescript-go/internal/checker.outerTypeParameters []*github.com/microsoft/typescript-go/internal/checker.Type }]).slot(SB)	

TEXT github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB) github.com/microsoft/typescript-go/internal/core/pointerlinkstore.go
  pointerlinkstore.go:31	0xa056e0		493b6610		CMPQ SP, 0x10(R14)																											
  pointerlinkstore.go:31	0xa056e4		0f86a8000000		JBE 0xa05792																												
  pointerlinkstore.go:31	0xa056ea		55			PUSHQ BP																												
  pointerlinkstore.go:31	0xa056eb		4889e5			MOVQ SP, BP																												
  pointerlinkstore.go:31	0xa056ee		4883ec10		SUBQ $0x10, SP																												
  pointerlinkstore.go:32	0xa056f2		488b5008		MOVQ 0x8(AX), DX																											
  pointerlinkstore.go:32	0xa056f6		488d72ff		LEAQ -0x1(DX), SI																											
  pointerlinkstore.go:25	0xa056fa		4889cf			MOVQ CX, DI																												
  pointerlinkstore.go:26	0xa056fd		4989c8			MOVQ CX, R8																												
  pointerlinkstore.go:26	0xa05700		48c1e91e		SHRQ $0x1e, CX																												
  pointerlinkstore.go:26	0xa05704		4c31c1			XORQ R8, CX																												
  pointerlinkstore.go:26	0xa05707		49b8b9e5e41c6d4758bf	MOVQ $0xbf58476d1ce4e5b9, R8																										
  pointerlinkstore.go:26	0xa05711		4c0fafc1		IMULQ CX, R8																												
  pointerlinkstore.go:27	0xa05715		4c89c1			MOVQ R8, CX																												
  pointerlinkstore.go:27	0xa05718		49c1e81b		SHRQ $0x1b, R8																												
  pointerlinkstore.go:27	0xa0571c		4931c8			XORQ CX, R8																												
  pointerlinkstore.go:27	0xa0571f		48b9eb113113bb49d094	MOVQ $0x94d049bb133111eb, CX																										
  pointerlinkstore.go:27	0xa05729		490fafc8		IMULQ R8, CX																												
  pointerlinkstore.go:28	0xa0572d		4989c8			MOVQ CX, R8																												
  pointerlinkstore.go:28	0xa05730		48c1e91f		SHRQ $0x1f, CX																												
  pointerlinkstore.go:28	0xa05734		4c31c1			XORQ R8, CX																												
  pointerlinkstore.go:32	0xa05737		4c8b00			MOVQ 0(AX), R8																												
  pointerlinkstore.go:33	0xa0573a		4821f1			ANDQ SI, CX																												
  pointerlinkstore.go:33	0xa0573d		31c0			XORL AX, AX																												
  pointerlinkstore.go:33	0xa0573f		90			NOPL																													
  pointerlinkstore.go:34	0xa05740		eb0a			JMP 0xa0574c																												
  pointerlinkstore.go:39	0xa05742		498d4901		LEAQ 0x1(R9), CX																											
  pointerlinkstore.go:39	0xa05746		4821f1			ANDQ SI, CX																												
  pointerlinkstore.go:34	0xa05749		48ffc0			INCQ AX																													
  pointerlinkstore.go:34	0xa0574c		4839d0			CMPQ AX, DX																												
  pointerlinkstore.go:34	0xa0574f		7d2d			JGE 0xa0577e																												
  pointerlinkstore.go:35	0xa05751		4839d1			CMPQ CX, DX																												
  pointerlinkstore.go:35	0xa05754		7323			JAE 0xa05779																												
  pointerlinkstore.go:35	0xa05756		4989c9			MOVQ CX, R9																												
  pointerlinkstore.go:35	0xa05759		48c1e104		SHLQ $0x4, CX																												
  pointerlinkstore.go:36	0xa0575d		4d8b540808		MOVQ 0x8(R8)(CX*1), R10																											
  pointerlinkstore.go:36	0xa05762		4d85d2			TESTQ R10, R10																												
  pointerlinkstore.go:36	0xa05765		7409			JE 0xa05770																												
  pointerlinkstore.go:36	0xa05767		498b0c08		MOVQ 0(R8)(CX*1), CX																											
  pointerlinkstore.go:36	0xa0576b		4839f9			CMPQ CX, DI																												
  pointerlinkstore.go:36	0xa0576e		75d2			JNE 0xa05742																												
  pointerlinkstore.go:37	0xa05770		4c89c8			MOVQ R9, AX																												
  pointerlinkstore.go:37	0xa05773		4883c410		ADDQ $0x10, SP																												
  pointerlinkstore.go:37	0xa05777		5d			POPQ BP																													
  pointerlinkstore.go:37	0xa05778		c3			RET																													
  pointerlinkstore.go:35	0xa05779		e822c1a8ff		CALL runtime.panicBounds(SB)																										
  pointerlinkstore.go:41	0xa0577e		488d055b575100		LEAQ 0x51575b(IP), AX																											
  pointerlinkstore.go:41	0xa05785		488d1d544acd00		LEAQ 0xcd4a54(IP), BX																											
  pointerlinkstore.go:41	0xa0578c		e80f43a8ff		CALL runtime.gopanic(SB)																										
  pointerlinkstore.go:41	0xa05791		90			NOPL																													
  pointerlinkstore.go:31	0xa05792		4889442408		MOVQ AX, 0x8(SP)																											
  pointerlinkstore.go:31	0xa05797		48895c2410		MOVQ BX, 0x10(SP)																											
  pointerlinkstore.go:31	0xa0579c		48894c2418		MOVQ CX, 0x18(SP)																											
  pointerlinkstore.go:31	0xa057a1		e85aa2a8ff		CALL runtime.morestack_noctxt.abi0(SB)																									
  pointerlinkstore.go:31	0xa057a6		488b442408		MOVQ 0x8(SP), AX																											
  pointerlinkstore.go:31	0xa057ab		488b5c2410		MOVQ 0x10(SP), BX																											
  pointerlinkstore.go:31	0xa057b0		488b4c2418		MOVQ 0x18(SP), CX																											
  pointerlinkstore.go:31	0xa057b5		e926ffffff		JMP github.com/microsoft/typescript-go/internal/core.(*PointerLinkStore[go.shape.7ef79b8109ca7a73e057574e4a0af0be1984d8606fab799593577d67d88dffe0,go.shape.d6cbdb9886be08dc6c9eab4296483119612961cb9874c1cd84b71bcfe563e7bf]).slot(SB)	
