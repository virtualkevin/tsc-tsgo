export interface Box<T> { read(): T }
export class Store<T> implements Box<T> {
 constructor(private value: T) {}
 read(): T { return this.value; }
 map<U>(f: (value: T) => U): Store<U> { return new Store(f(this.value)); }
}
export function identity<T>(value: T): T { return value; }
export type Project<T> = { [K in keyof T]: T[K] extends object ? Project<T[K]> : T[K] };
