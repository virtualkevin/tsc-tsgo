import { Store, identity, type Project } from "./types.js";
const store = new Store({ value: 3 });
const result = store.map(x => ({ nested: x.value }));
const value: number = result.read().nested;
const tuple = identity<[number, string]>([3, "ok"]);
const projected: Project<typeof tuple> = tuple;
export const answer = { value, projected };
