from pathlib import Path
import os,json,re,hashlib,subprocess,sys,traceback
ROOT=Path('/home/dev/tssss/tsc-tsgo'); OUT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/tsc-semantic-census-validation/cli')
OUT.mkdir(); FIX=OUT/'fixture';FIX.mkdir()
BASE=ROOT/'packages/tsc-go/dist/tsc-go-keybuilder-saturated';CAND=ROOT/'packages/tsc-go/dist/tsc-go-semantic-census'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected={str(BASE):'2bdcca53f630535846054eada84cae8afaa32b4faab21de029eca41c79e26303',str(CAND):'5f038b8c3ae8c7ac7b7003c9a41367a5dbcabfeaf3b24b45ad1b1f553c41c080'}
report={'status':'running','kind':'diagnostic-only CLI validation; no performance evidence','controllerSha256':sha(__file__),'binaries':expected,'runs':[],'comparisons':[]}
def save(): (OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for p,h in expected.items():assert sha(p)==h
sidecars={str(p)+'.provenance.json':sha(str(p)+'.provenance.json') for p in [BASE,CAND]};report['sidecarSha256']=sidecars
source=json.loads(Path('/tmp/tsc-semantic-census-validation/source-final.json').read_text())
for f in source['files']:assert sha(ROOT/f['path'])==f['sha256']
report['sourceSha256']=source['sourceSha256']
(FIX/'package.json').write_text('{"type":"module"}\n')
(FIX/'types.ts').write_text('''export interface Box<T> { read(): T }
export class Store<T> implements Box<T> {
 constructor(private value: T) {}
 read(): T { return this.value; }
 map<U>(f: (value: T) => U): Store<U> { return new Store(f(this.value)); }
}
export function identity<T>(value: T): T { return value; }
export type Project<T> = { [K in keyof T]: T[K] extends object ? Project<T[K]> : T[K] };
''')
for i in range(8):
 (FIX/f'consumer{i}.ts').write_text(f'''import {{ Store, identity, type Project }} from "./types.js";
const store = new Store({{ value: {i} }});
const result = store.map(x => ({{ nested: x.value }}));
const value: number = result.read().nested;
const tuple = identity<[number, string]>([{i}, "ok"]);
const projected: Project<typeof tuple> = tuple;
export const answer = {{ value, projected }};
''')
fixture_source=(ROOT/'packages/tsc-go/internal/checker/jsx_managed_attributes_errors_api_test.go').read_text()
jsx=re.search(r'const source = `([\s\S]*?)`',fixture_source).group(1)
(FIX/'errors.tsx').write_text(jsx+'\nconst forcedError: number = "wrong";\n')
files=['types.ts']+[f'consumer{i}.ts' for i in range(8)]
for case in ['clean','errors']:
 options={'strict':True,'target':'es2022','module':'nodenext','moduleResolution':'nodenext','skipLibCheck':True,'jsx':'preserve','declaration':case=='clean','noEmit':True}
 (FIX/f'tsconfig.{case}.json').write_text(json.dumps({'compilerOptions':options,'files':files+(['errors.tsx'] if case=='errors' else [])})+'\n')
report['fixtureFiles']={p.name:sha(p) for p in sorted(FIX.iterdir())}
env={k:v for k,v in os.environ.items() if not k.startswith(('TSC_','TS_GO_')) and k not in ['GOFLAGS','GOEXPERIMENT','GOGC','GOMEMLIMIT','GOMAXPROCS','GODEBUG','CPUPROFILE','HEAPPROFILE','NODE_OPTIONS']}
env['TSC_TS_LIB_DIR']=str(ROOT/'upstream/typescript-go/internal/bundled/libs')
report['compilerEnvironment']={'TSC_TS_LIB_DIR':env['TSC_TS_LIB_DIR']}
def invoke(binary,args,name,observe=None,labels=None):
 e=dict(env)
 if observe is not None:e['TSC_GO_CENSUS']=str(observe);e['TSC_GO_CENSUS_CPU_LABELS']=str(labels)
 r=subprocess.run([str(binary),*args],cwd=FIX,env=e,capture_output=True,text=True,timeout=180)
 (OUT/(name+'.stdout')).write_text(r.stdout);(OUT/(name+'.stderr')).write_text(r.stderr)
 report['runs'].append({'name':name,'command':[str(binary),*args],'cwd':str(FIX),'exitCode':r.returncode,'stdoutSha256':sha(OUT/(name+'.stdout')),'stderrSha256':sha(OUT/(name+'.stderr')),'census':str(observe) if observe else None,'labels':labels})
 save();return r
semantic=['Files','Lines','Identifiers','Symbols','Types','Instantiations']
allowed=set(semantic+['Memory used','Memory allocs','Config time','BuildInfo read time','Parse time','Bind time','Check time','Emit time','Changes compute time','Total time'])
def split_output(r):
 m=re.search(r'^Files:\s+\d+\s*$',r.stdout,re.M);assert m,'statistics absent'
 stats={}
 for line in r.stdout[m.start():].splitlines():
  key,value=line.split(':',1);assert key in allowed,(key,line);assert key not in stats;stats[key]=value.strip()
 return r.stdout[:m.start()],{k:int(stats[k]) for k in semantic}
def census(path,owners):
 lines=[json.loads(x) for x in path.read_text().splitlines()];header,*rows=lines
 assert header['semanticallyEquivalentResultsProven'] is False and header['schemaVersion']==1
 assert len(rows)==owners and len({r['checkerId'] for r in rows})==owners
 families={};diagnostics=0;overflow=0;records=0
 for owner in rows:
  diagnostics+=owner['diagnosticAdditions'];overflow+=owner['overflow']['Calls'];records+=len(owner['records'])
  assert len(owner['records'])<=header['recordLimitPerChecker']
  assert [r['ID'] for r in owner['records']]==list(range(len(owner['records'])))
  for r in owner['records']+[owner['overflow']]:
   assert 0<=r['ExclusiveNanoseconds']<=r['InclusiveNanoseconds']
   assert 0<=r['ReturnedNormally']<=r['Calls']
   assert 0<=r['DiagnosticSpans']<=r['Calls']
   if r['Calls']:families[r['Family']]=families.get(r['Family'],0)+r['Calls']
 assert all(families.get(f,0)>0 for f in ['signature-construction-miss','resolved-signature-miss','class-interface-construction-miss','type-instantiation-miss'])
 return {'sha256':sha(path),'owners':len(rows),'recordCount':records,'familyCalls':families,'diagnosticAdditions':diagnostics,'overflowCalls':overflow,'sharingEligibility':'unclassified'}
try:
 for case in ['clean','errors']:
  for owners in [1,4]:
   prefix=f'{case}-{owners}'
   args=['-p',f'tsconfig.{case}.json','--noEmit','--incremental','false','--composite','false','--noCheck','false','--pretty','false','--checkers',str(owners)]
   a=invoke(BASE,args+['--listFilesOnly'],prefix+'-baseline-inputs');b=invoke(CAND,args+['--listFilesOnly'],prefix+'-candidate-inputs')
   assert a.returncode==b.returncode==0 and a.stdout==b.stdout and a.stderr==b.stderr==''
   inputs={str(Path(x) if Path(x).is_absolute() else FIX/x):sha(Path(x) if Path(x).is_absolute() else FIX/x) for x in a.stdout.splitlines()};assert inputs
   a=invoke(BASE,args+['--extendedDiagnostics'],prefix+'-baseline');ad,ac=split_output(a)
   if case=='clean':assert a.returncode==0 and ad=='' and a.stderr==''
   else:assert a.returncode in [1,2] and ad.count('error TS2589:')==2 and ad.count('error TS2322:')==1 and a.stderr==''
   for labels in [0,1]:
    name=prefix+f'-labels{labels}';path=OUT/(name+'.census.jsonl')
    b=invoke(CAND,args+['--extendedDiagnostics'],name,path,labels);bd,bc=split_output(b)
    assert a.returncode==b.returncode and ad==bd and a.stderr==b.stderr,'diagnostics or exit status changed'
    assert ac==bc,('semantic counters changed',ac,bc)
    observed=census(path,owners);assert (observed['diagnosticAdditions']==0)==(case=='clean')
    assert all(sha(p)==h for p,h in inputs.items())
    report['comparisons'].append({'case':case,'checkers':owners,'labels':labels,'diagnosticText':bd,'semanticCounters':bc,'inputCount':len(inputs),'inputs':inputs,'census':observed});save()
 for p,h in expected.items():assert sha(p)==h
 for p,h in sidecars.items():assert sha(p)==h
 for f in source['files']:assert sha(ROOT/f['path'])==f['sha256']
 assert sha(__file__)==report['controllerSha256']
 report['status']='passed'
except BaseException:
 report['status']='failed';report['error']=traceback.format_exc();raise
finally:save()
print(json.dumps({'status':report['status'],'comparisons':len(report['comparisons']),'report':str(OUT/'summary.json')}))
